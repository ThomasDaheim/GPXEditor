<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Results View Page
	Created by Dustin Poissant on 10/11/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Results - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/graph.class.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/results.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='loadScroll()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'  id='onlink'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px''>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				View the Results
			</div> <!-- End of 'pageTitle' div -->
			<?php
				$handle = fopen("./results/results.txt", 'w');
				fwrite($handle, "The results of this Curve Simplification Turk Study is as follows.");
				fwrite($handle, "\n");
				$readin = file('results/alg1.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg1Count='.$count.';</script>';
				}
				$readin = file('results/alg2.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg2Count='.$count.';</script>';
				}
				$readin = file('results/alg3.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg3Count='.$count.';</script>';
				}
				$readin = file('results/alg4.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg4Count='.$count.';</script>';
				}
				$readin = file('results/alg5.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg5Count='.$count.';</script>';
				}
				$readin = file('results/alg6.txt');
				$count=0;
				foreach($readin as $count){
					echo '<script> var alg6Count='.$count.';</script>';
				}
			?>
			<br>
			<br>
			<center>
			<div class='insetBox'>
					<br>
					<br>
					<br>
					<div id="graphDIV" class='box' width='600px'>
						Your browser does not support HTML5
						<br>
						<br>
						The Douglas-Peucker Algorithm has been selected 
						<script>document.write(alg1Count);</script>
						times.
						<br>
						The Visvalingam-Whyat Algorithgm has been selected 
						<script>document.write(alg2Count);</script>
						times.
						<br>
						The Opheim Algorithm has been selected 
						<script>document.write(alg3Count);</script>
						times.
						<br>
						The Radial Distance Algorithm has been selected 
						<script>document.write(alg4Count);</script>
						times.
						<br>
						The Perpendicular Distance Algorithm has been selected 
						<script>document.write(alg5Count);</script>
						times.
						<br>
						The Reumann-Witkam Algorithm has been selected 
						<script>document.write(alg6Count);</script>
						times.
						<br>
						<br>
					</div> <!-- End of 'graphDIV' div -->
					<br>
					<br>
					<br>
			</div>
			<script>
				var graph= new Graph("graphDIV");
				graph.setSize(800, 500);
				graph.setTitle("Algorithm Selection");
				//graph.setBackground("images/chartBG.png");
				graph.setMaxHeight(90);
				graph.setBarWidth(80);
				graph.setTextColor("black");
				graph.addBar("Douglas-Puecker", alg1Count, "red");
				graph.addBar("Visvalingam -Whyatt", alg2Count, "lime");
				graph.addBar("Opheim", alg3Count, "white");
				graph.addBar("Radial Distance", alg4Count, "yellow");
				graph.addBar("Perpendicular Distance", alg5Count, "orange");
				graph.addBar("Reumann-Witkam", alg6Count, "aqua");
				graph.generate();
			</script>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Image Repository Page
	Created by Dustin Poissant on 10/10/2012.
	Edited by Dustin Poissant on 10/16/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Image Repository - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/math.lib.js'></script>
	<script type='text/javascript' src='./res/js/douglas.lib.js'></script>
	<script type='text/javascript' src='./res/js/whyatt.lib.js'></script>
	<script type='text/javascript' src='./res/js/nthPoint.lib.js'></script>
	<script type='text/javascript' src='./res/js/randomDeltion.lib.js'></script>
	<script type='text/javascript' src='./res/js/radial.lib.js'></script>
	<script type='text/javascript' src='./res/js/perp.lib.js'></script>
	<script type='text/javascript' src='./res/js/reumann.lib.js'></script>
	<script type='text/javascript' src='./res/js/opheim.lib.js'></script>
	<script type='text/javascript' src='./res/js/reumann.lib.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/images_repository.css' />
	<!-- End of imports -->
	<script>
		var p= new Array();
		<?php
			$filePath="./curves/";
			if (glob($filePath . "*.txt") != false){
			 $filecount = count(glob($filePath . "*.txt"));
			}
			for($i=0;$i<$filecount;$i++){
				echo "p[".$i."]= new PointList();";
				$file=fopen($filePath.($i+1).".txt","r");
				$size= fgets($file);
				for ($e=0;$e<$size;$e++){
					echo "p[".$i."].addPoint(".fgets($file).", ".fgets($file).");";
				}
				fclose($file);
			}
		?>
		function select(imageNumber){
			document.getElementById('imageSelection').value= imageNumber;
			document.getElementById('imgSelection').submit();			
		}
	</script>
	<style>
		#images canvas {
			margin: 10px;
			cursor: pointer;
		}
		canvas:hover {
			cursor: pointer;
			border-top: 1px solid #555;
			border-right: 1px solid #555;
			border-left: 1px solid #555;
			border-bottom: 1px solid #ddd;
			box-shadow:
				0px 1px 30px #ddd,
				0px -1px 30px #ddd,
				inset 0px 1px 1px #555,
				inset 0px 2px 0px #555,
				inset 0px 3px 0px #555,
				inset 0px 4px 0px #555,
				inset 0px 5px 0px #555,
				inset 0px 6px 1px #555,
				inset 0px 7px 1px #555,
				0px 0px 10px white,
				0px 1px 0px white,
				0px 2px 5px #ddd;
			position: relative;
			top: 8px;
			background: #CCC;
		}
		#subtitle {
			text-align: center;
			font-size: 24px;
		}
	</style>
</head>
<body onload="onload()" onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' div-->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'  id='onlink'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Image Repository
			</div> <!-- End of 'pageTitle' div -->		
			<div id='subtitle'>
				<a href='./images_image.php'>View Individual Images and Simplifications.</a>
			</div> <!-- End of 'subtitle' div -->
			<br>
			<form id="imgSelection" action="images_image.php" method="post">
				<div id="images">
					<script>
						for (var i=0; i<p.length; i++){
							document.write("<canvas id='c"+i+"' width='200px' height='200px' class='box' onclick='select("+(i+1)+");'></canvas>");
							var c= new Canvas(('c'+i));
							c.addPointList(p[i].halfSize());
							c.draw();
						}
					</script>
				</div> <!-- End of 'images' div -->
				<input id='imageSelection' name='imageSelection' type='hidden' value='0' />
			</form> <!-- End of 'imgSelection' form -->
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
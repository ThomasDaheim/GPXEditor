<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Code Page
	Created by Dustin Poissant on 10/11/2012.
	Edited by Dustin Poissant on 10/13/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Code - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/pointList.class.js'></script>
	<script type='text/javascript' src='../res/js/canvas.class.js'></script>
	<script type='text/javascript' src='../res/js/math.lib.js'></script>
	<script type='text/javascript' src='../res/js/radial.lib.js'></script>
	<script type='text/javascript' src='../res/js/douglas.lib.js'></script>
	<script type='text/javascript' src='../res/js/nthPoint.lib.js'></script>
	<script type='text/javascript' src='../res/js/whyatt.lib.js'></script>
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script> 
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_code.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='information'>
				<div id='pageTitle'>
					About the Code: Code Overview
				</div> <!-- End of 'pageTitle' div -->
				<h2>Code used in this project: </h2>
				<ul>
					<li><a href='point.php'>Point Class</a></li>
					<li><a href='pointList.php'>PointList Class</a></li>
					<li><a href='canvas.php'>Canvas Class</a></li>
					<li><a href='math.php'>Math Library</a></li>
					<li><a href='randomDeletion.php'>Random Deletion Library</a></li>
					<li><a href='douglas.php'>Douglas-Peucker Library</a></li>
					<li><a href='whyatt.php'>Visvalingam-Whyatt Library</a></li>
					<li><a href='NthPoint.php'>Nth Point Elimination Library</a></li>
					<li><a href='radial.php'>Radial Distance Library</a></li>
					<li><a href='perp.php'>Perpendicular Distance Library</a></li>
					<li><a href='reumann.php'>Reumann-Witkam Library</a></li>
					<li><a href='opheim.php'>Opheim Library</a></li>
					<li><a href='lang.php'>Lang Library</a></li>
				</ul>
				<br>
				<h2 id='issues'>Known Issues: </h2>
				<ul>
					<li>
						Shapes
						<ul>
							<li>Shapes are completely enclosed lines, meaning their first and last points are of the same value.</li>
							<li>This causes problems for the Douglas-Peucker Algorithm because at the start of the Douglas Peucker Algorithm a line is drawn from the first to last point and then each point's distance is calculated from this line. If the first and last points are the same a line cannot be made from them causing the Algorithm to break.</li>
							<li>To make a fair assessment of Line Simplification Algorithms the Douglas-Peucker Algorithm goes first (because it cannot predetermine the number of points to keep, and then all other Algorithms are forced to return the same number of points as the Douglas-Peucker Algorithm. So when a shape breaks the Douglas-Peucker Algorithm it returns only the first and last point (which are the same) and all other algorithms follow suit leaving all simplified canvases to appear empty.</li>
							<li>Lines crossing one another is not a problem for the Douglas-Peucker Algorithm, so lines may be drawn that appear to be a closed shape if the first and last line segments (first two points and last two points) overlap each other. If the start and end points are a few coordinate values appart and the first and last line segments are crossing, the Douglas-Peucker Algorithm will still work and the line will appear to be a closed shape.</li>
						</ul>
					</li>
					<li>
						Cross Browser Support	
						<ul>
							<li>All features work on all browsers except Internet Explorer.</li>
							<li>Problems with Internet Explorer.
								<ul>
									<li>The graph on the results page is not scaled properly.</li>
									<li>The create feature is currently offline for Internet Explorer. The reasons for this are:
										<ul>
											<li>Dynamic generation of the Point List Table fails</li>
											<li>Drawing on the canvas fails</li>
										</ul>
									</li>
									<li>
										Problems Clearing the Canvas.
										<ul>
											<li>In the repository feature when selecting a new algorithm, the image from the new algorithm is overlayed onto the image from the previously selected algorithm.</li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
					</li>
				</ul>
				<br>
				<hr>
				<br>
				<h2>Sample Program</h2>
				<ul>
					<li>The Point Class is used to store the X and Y coordinates relating to positions on each canvas.</li>
					<li>The PointList Class holds all Point objects and makes available usefull functions such as halfSize() which is used below.</li>
					<li>The Canvas Class is used to assign a PointList object to a canvas and draw it.</li>
					<li>The Math Library has many functions that are used in the Random Deletion, Douglas-Peucker, and Visvalingam-Whyatt Libraries.</li>
					<li>Random Deletion, Douglas-Peucker, and Visvalingam-Whyatt Libraries are used to generate the PointList object displayed on the corresponding canvases.</li>
				</ul>
			</div> <!-- End of 'information' div -->
			<?php
				include_once './code/code.html';
			?>
			<br>
			<br>
				<div id='pageTitle'>
					Sample Program Code:
				</div> <!-- End of 'title' div -->
				<div id='code'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = file_get_contents('./code/code.html');
						$language= 'php';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

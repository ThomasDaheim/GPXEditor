<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Code Page - Math Library
	Created by Dustin Poissant on 10/13/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Code - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script> 
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_code.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='information'>
				<div id='pageTitle'>
					About the Code: Math Library
				</div> <!-- End of 'pageTitle' div -->
				<h2>Description: </h2>
				<ul>
					<li>Contains functions to assist with mathematical calculations.</li>
				</ul>
				<br>
				<h2>Contained Classes:</h2>
				<ul>
					<li>Line(Point1, Point2) - Holds two points that form a line.
					<ul>
						<li>p1 - Public Member that holds 'Point1'.</li>
						<li>p2 - Public Member that holds 'Point2'.</li>
					</ul>
				</ul>
				<h2>Functions:</h2>
				<ul>
					<li>distance(point1, point2) - Returns the distance between 'point1' and 'point2'.</li>
					<li>distaneToLine(Line, Point) - Returns the distance between a Line object and a point.</li>
					<li>triangleArea(Point1, Point2, Point3) - Returns the area of a triangle formed by the three Points parameters.</li>
					<li>randomInt(min, max) - Returns a random Integer between 'min' and 'max'.</li>
				</ul>
				<br>
				<h2>Math Library code:</h2>
				<ul>
					<li><a href='../res/js/math.lib.js'>math.lib.js</a></li>
				</ul>
				<br>
				<h2>Dependencies:</h2>
				<ul>
					<li><a href='point.php'>Point Class</a></li>
				</ul>
				<br>
				<hr>
				<br>
				<h2>Sample Program:</h2>
				<ul>
					<li>Create a PointList, add 3 points to the PointList.</li>
					<li>Display the PointList.</li>
					<li>Display the distance between point 1 and point 2.</li>
					<li>Create a Line object using point 1 and point 2.</li>
					<li>Display the distance between this line and point 3.</li>
					<li>Display the area of a triangle formed from all 3 points.</li>
					<li>Display 5 Random Integers between 0 and 100.</li>
				</ul>
				<br>
			</div> <!-- End of 'information' div -->
			<!-- included using PHP -->
			<?php
				include_once './code/math.html';
			?>
			<br>
			<br>
				<div id='pageTitle'>
					Sample Program Code:
				</div> <!-- End of 'title' div -->
				<div id='code'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = file_get_contents('./code/math.html');
						$language= 'php';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<!--
	CS 370 Project - Curve Simplification Turk, Version 2.1
	About the Code Page - Lang Library Test Page
	Created by Dustin Poissant on 11/02/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Code - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script> 
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_code.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='information'>
				<div id='pageTitle'>
					About the Code: <br>Lang Library
				</div> <!-- End of 'pageTitle' div -->
				<h2>Description: </h2>
				<ul>
					<li>Contains a function which impliments the Lang Algorithm.
						<ul>
							<li>See<a href='../about_algorithms/lang'>"About The Lang Algorithm"</a>for more information on the Lang Algorithm.</li>
						</ul>
					</li>
				</ul>
				<h2>Functions:</h2>
				<ul>
					<li>lang(PointList, Tolerance) - Returns a PointList object simplified from the 'PointList' parameter using the Lang Algorithm.</li>
				</ul>
				<br>
				<h2>Lang Library code:</h2>
				<ul>
					<li><a href='../res/js/lang.lib.js'>lang.lib.js</a></li>
				</ul>
				<br>
				<h2>Dependencies:</h2>
				<ul>
					<li><a href='pointList.php'>PointList Class</a></li>
					<li><a href='math.php'>Math Library</a></li>
				</ul>
				<br>
				<h2>Other Classes used in the Sample Program:</h2>
				<ul>
					<li><a href='canvas.php'>Canvas Class</a></li>
				</ul>
				<br>
				<hr>
				<br>
				<h2>Sample Program:</h2>
				<ul>
					<li>Create two HTML Canvas elements.</li>
					<li>Create a PointList object, add 15 points to it.</li>
					<li>Create two Canvas objects, one for each Canvas element.</li>
					<li>Assign the PointList object to the first canvas and draw it.</li>
					<li>Create a new PointList object from the return of the Lang Algorithm on the original PointList object.</li>
					<li>Assign this new PointList object to the second canvas and draw it.</li>
					<li>Display both PointList objects.</li>
				</ul>
				<br>
			</div> <!-- End of 'information' div -->
			<!-- included using PHP -->
			<?php
				include_once './code/lang.html';
			?>
			<br>
			<br>
				<div id='pageTitle'>
					Sample Program Code:
				</div> <!-- End of 'title' div -->
				<div id='code'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = file_get_contents('./code/lang.html');
						$language= 'php';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

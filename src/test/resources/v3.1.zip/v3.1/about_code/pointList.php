<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Code Page - PointList Class
	Created by Dustin Poissant on 10/13/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Code - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/pointList.class.js'></script>
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script> 
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_code.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='information'>
				<div id='pageTitle'>
					About the Code: PointList Class
				</div> <!-- End of 'pageTitle' div -->
				<h2>Description: </h2>
				<ul>
					<li>A container for Point objects.</li>
					<li>Contains methods to add, remove, and get points.</li>
					<li>Contains other useful container class methods.</li>
				</ul>
				<h2>Constructor: </h2>	
				<ul>
					<li>PointList() - Takes no parameters.</li>
				</ul>
				<br>
				<h2>Public Members:</h2>
				<ul>
					<li>list -  An Array of contained Point objects.</li>
				</ul>
				<br>
				<h2>Public Methods:</h2>
				<ul>
					<li>addPoint(x,y) - Creates a new Point object using 'x' and 'y'.</li>
					<li>removePoint(index) - Removes the point at location 'index'.</li>
					<li>getPoint(index) - Returns the point at location 'index'.</li>
					<li>size() - Returns the number of Point objects contained.</li>
					<li>clone() - Returns a hard copy of this object, changes to a hard copy will not effect the original.</li>
					<li>halfSize() - Returns a hard copy of this object with each Point object's value half that of this object's.</li>
					<li>combine(PointList) - Adds all points from the 'PointList' parameter to this PointList object.</li>
					<li>toString() - Returns a string with each Point object's 'toString()' on seperate lines.</li>
				</ul>
				<br>
				<h2>PointList Class code:</h2>
				<ul>
					<li><a href='../res/js/pointList.class.js'>pointList.class.js</a></li>
				</ul>
				<br>
				<h2>Dependencies:</h2>
				<ul>
					<li><a href='point.php'>Point Class</a> (contained in the same file)</li>
				</ul>
				<br>
				<hr>
				<br>
				<h2>Sample Program:</h2>
				<ul>
					<li>Create a PointList object.</li>
					<li>Add 5 points to the PointList object.</li>
					<li>Display the PointList.</li>
					<li>Remove the point at location 2.</li>
					<li>Display the PointList.</li>
					<li>Get and display the point at location 1.</li>
					<li>Get and display the size of this PointList.</li>
					<li>Create a clone of this PointList.</li>
					<li>Remove the point at location 0 from the clone and display both PointLists.</li>
					<li>Combine the clone into the oringal and display the results.</li>
					<li>Create and display a half sized version of the original PointList object.</li>
				</ul>
				<br>
			</div> <!-- End of 'information' div -->
			<!-- included using PHP -->
			<?php
				include_once './code/pointList.html';
			?>
			<br>
			<br>
				<div id='pageTitle'>
					Sample Program Code:
				</div> <!-- End of 'title' div -->
				<div id='code'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = file_get_contents('./code/pointList.html');
						$language= 'php';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<!--
	CS 370 Project - Curve Simplification Turk, Version 2.2
	Main Project Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Home - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<script type='text/javascript' src='./res/js/PowerPoint.class.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/index.css' />
	<!-- End of imports -->
	<script>
		function onload(){
			loadScroll();
		}
	</script>
	<style>
		#project {
			cursor: pointer;
			width: 275px;
			height: 30px;
			font-size: 22px;
			background: white;
			font-family:Georgia;
			text-align: center;
			border: 2px solid blue;
			border-radius: 25px;
			padding: 5px;
			margin: 10px auto;
		}
		#project:hover {
			border: 2px solid white;
			background-color: blue;
			color: white;
		}
		#layout a, #layout a:link, #layout a:visited, #layout a:active {
			color: blue;
			text-decoration: none;
		}
		#layout a:hover {
			color: white;
			text-decoration: none;
		}
		#powerPoint {
			height: 700px;
			margin: 50px auto;
		}
		#ppImg {
			width: 900px;
			border-radius: 10px;
		}
		#next, #back {
			position: relative;
			top: -400px;
			opacity: 0.05;
			-webkit-transition : all .7s;
			-moz-transition : all .7s;
			-o-transition : all .7s;
			transition : all .7s;
			cursor: pointer;
		}
		#next:hover, #back:hover {
			opacity: 1;
		}
		#next {
			float: right;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px'  id='onlink'>Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id="layout">
				<div id="powerPoint">
					<img src='./res/images/about_project/Slide1.png' id='ppImg' class='box' onclick='p.next()' />
					<img src='./res/images/back.png' id='back' onclick='p.back()' />
					<img src='./res/images/next.png' id='next' onclick='p.next()' />
					<script>
						var p= new PowerPoint('ppImg');
						p.add('./res/images/about_project/Slide1.png');
						p.add('./res/images/about_project/Slide2.png');
						p.add('./res/images/about_project/Slide3.png');
						p.add('./res/images/about_project/Slide4.png');
						p.add('./res/images/about_project/Slide5.png');
						p.add('./res/images/about_project/Slide6.png');
						p.add('./res/images/about_project/Slide7.png');
						p.add('./res/images/about_project/Slide8.png');
						p.add('./res/images/about_project/Slide9.png');
						p.add('./res/images/about_project/Slide10.png');
						p.add('./res/images/about_project/Slide11.png');
						p.add('./res/images/about_project/Slide12.png');
						p.add('./res/images/about_project/Slide13.png');
						p.add('./res/images/about_project/Slide14.png');
					</script>
				</div> <!-- End of 'powerPoint' div -->
				<a href="./project.php"><div id='project' class='box'>Begin the Project</div></a>
			</div> <!-- End of 'layout' div -->
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<div id="counterWrapper" class="box">
					Visitors: 
					<?php
						$file= fopen("./res/data/counter","r");
						$counter= fgets($file);
						fclose($file);
						$counter+=1;
						echo $counter;
						$handle = fopen("./res/data/counter", 'w');
						fwrite($handle, $counter);
						fclose($handle);
					?>
				</div>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Project Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Project - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/about_project.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
	<style>
		#powerPoint {
			height: 700px;
		}
		#ppImg {
			width: 900px;
			border-radius: 10px;
		}
		#next, #back {
			position: relative;
			top: -400px;
			opacity: 0.05;
			-webkit-transition : all .7s;
			-moz-transition : all .7s;
			-o-transition : all .7s;
			transition : all .7s;
			cursor: pointer;
		}
		#next:hover, #back:hover {
			opacity: 1;
		}
		#next {
			float: right;
		}
		#install {
			font-size: 1.5em;
			text-indent: 1em;
			line-height: 1.5em;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<p id="install">
				<a href="v3.0.zip">Download the project to your server.</a> Unzip in your servers root directory or create a link to the index.php within the unziped file. Your server must support PHP.
			</p>
			<p id="install">
				To run a server on your local machine visit <a href="http://www.apachefriends.org/en/xampp.html">Xampp</a> for instructions.
			</p>
            <p>
            <h3>A Brief History of Curve Simplification</h3>
            <ul>
                <li>In 1954 Fred Attneave published an article titled <a href="pdf/1954.pdf">"Some Informational Aspects of Visual Perception"</a> in which he discussed the mathematical relivance of points of a curve. In this article he presented his findings on how some points hold a higher visualy percptive value than others in a curve.</li>
                <li>In 1972 Urs Ramer published an article titled <a href="pdf/1972.pdf">"An Iterative Procedure for the Polygonal Approximation of Plane Curves"</a>. In this article Ramer proposed an iterative (recursive) procedure for determining the relivance of points in Plane Curve.</li>
                <li>A year later, in 1973, David Douglas and Thomas Peucker propsed a computational recursive function which implimented Ramers interative procedure. Their article <a href="pdf/1973.pdf">"Algorithms for the Reduction of the Number of Points Required to Represent a Digitized Line or it's Caricature"</a> laid out the foundationg on which future Curve Simplification Algorithms would be based. This algorithm became known as the Douglas-Peucker, or Ramer-Douglas-Peucker, Algorithm.</li>
                <li>In 1985 <a href="pdf/1985.pdf"> "Assessment of Line-Generalization Algorithms Using Characteristic Points"</a>, This study describes experietments utilizing base lines of perceptually selected critical points to evaluate three common line-generalizaiton algorithms; nth-point elimination, a perpendicular routine, and the Douglas algorithm.</li>
                <li>In 1987 <a href="pdf/1987.pdf"> "Automated Line Generalization"</a>, that discussed the need for Curve Simplification which includes the reduncancy of many points being drawn in the same pixel.</li>
                <li>In 1993 M. Visvalingam and J. D. Whyatt discussed the difference between algorithms in their article <a href="pdf/1993.pdf">"Line Gerealisation by repeated elimination of points"</a>. The pros and cons of each algorithm are outlined in this article.</li>
                <li>In 1998 Zeshen Wang and Jean-Claude Muller proposed a new algorithm for Curve Simplification in their article <a href="pdf/1998.pdf">"Line Generalization Based on Analysis of Shape Characteristics"</a>. Their new algorithm looked at techniques used by cartographers for inspiration. Basic cartographers rules such as "two similar ajacent curves should be combined if their sizes lay under a threshhold", and "Small bends and irregularities should be remobed". From these cartogrphy techniques the Bendsimplification Algorithm was born.</li>
		<li>In 1999 <a href="pdf/1999.pdf">"Topologically Consistent Line Simplification with the Douglas-Peucker Algorithm"</a> This article examines key properties of the Douglas-Peucker polyline simplification algorithm which are shared with many similar "vertex sub-sampling" algorithms. It also describes all the pros and cons of these algorithms and experiments taht were preformed on the subject. </li>
		<li>In 2005 <a href="pdf/2005.pdf">"Near-Linear Time Approximation Algorithms for Curve Simplification"</a> This article is about considering the problem of approximating a polygonal curve and the goal is to find a way to minimize the numbers of vectors in the curve while ensuring it dosnt hit a certin error threshold. </li>
		<li>In 2007 <a href="pdf/2007.pdf">"Streaming Algorithms for Line Simplification" </a> This article goes over certain problems that are well known. It analyzes certian fixes for this problem and gets into detail about the probelm and how different algortihms effect it in different ways. </li>
           </ul>
           </p>
	   <h3><a href='../porject.html'>Previoud Versions:</a></h3>
            <ul>
				<li><a href='../v0.1b/index.php'>Version 0.1b</a></li>
				<li><a href='../v0.2b/index.php'>Version 0.2b</a></li>
				<li><a href='../v0.3b/index.php'>Version 0.3b</a></li>
				<li><a href='../v0.4b/index.php'>Version 0.4b</a></li>
				<li><a href='../v1.0/index.php'>Version 1.0</a></li>
				<li><a href='../v1.1/index.php'>Version 1.1</a></li>
				<li><a href='../v1.2/index.php'>Version 1.2</a></li>	
				<li><a href='../v2.0/index.php'>Version 2.0</a></li>	
				<li><a href='../v2.1/index.php'>Version 2.1</a></li>
				<li><a href='../v2.2/index.php'>Version 2.2</a></li>	
            </ul>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<!--
	CS 370 Project - Curve Simplification Turk, Version 2.0
	Main Project Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Project - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/math.lib.js'></script>
	<script type='text/javascript' src='./res/js/randomDeletion.lib.js'></script>
	<script type='text/javascript' src='./res/js/douglas.lib.js'></script>
	<script type='text/javascript' src='./res/js/whyatt.lib.js'></script>
	<script type='text/javascript' src='./res/js/opheim.lib.js'></script>
	<script type='text/javascript' src='./res/js/radial.lib.js'></script>
	<script type='text/javascript' src='./res/js/perp.lib.js'></script>
	<script type='text/javascript' src='./res/js/reumann.lib.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/index.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		var orderArray= new Array();
		for (var i=0; i<6; i++){
			orderArray[i]=i+1;
		}
		shuffle(orderArray);
		function addPointsFromRandomFile(PointList){
			var lines= new Array();
			<?php
				$filePath="./curves/";
				if (glob($filePath . "*.txt") != false)
				{
				 $filecount = count(glob($filePath . "*.txt"));
				}
				$fileNumber= rand(1,$filecount);
				$file=fopen($filePath.$fileNumber.".txt","r");
				$size= fgets($file);
				for ($i=0;$i<$size;$i++){
					echo "PointList.addPoint(".fgets($file).", ".fgets($file).");";
				}
				fclose($file);
			?>
		}
        function shuffle(ary) {
            var s = [];
            while (ary.length){
                s.push(ary.splice(Math.random() * ary.length, 1));
            }
            while (s.length){
                ary.push(s.pop());
            }
        }
		function onload(){
			loadScroll();
			var Canvas_original= new Canvas('originalCanvas');
			var pointList= new PointList();
			addPointsFromRandomFile(pointList);
			Canvas_original.addPointList(pointList);
			Canvas_original.draw();
			var Canvas_img1= new Canvas('img1Canvas');
			var Canvas_img2= new Canvas('img2Canvas');
			var Canvas_img3= new Canvas('img3Canvas');
			var Canvas_img4= new Canvas('img4Canvas');
			var Canvas_img5= new Canvas('img5Canvas');
			var Canvas_img6= new Canvas('img6Canvas');
			var dList= douglas(pointList, 5);
			var wList= whyatt(pointList, dList.size());
			var oList= opheim(pointList, 50, 85);
			var rList= radial(pointList, 30);
			var pList= perp(pointList, 5.5);
			var reList= reumann(pointList, 55);
			if (orderArray[0]==1){
				Canvas_img1.addPointList(dList.halfSize());
			} else if (orderArray[0]==2){
				Canvas_img1.addPointList(wList.halfSize());
			} else if (orderArray[0]==3){
				Canvas_img1.addPointList(oList.halfSize());
			} else if (orderArray[0]==4){
				Canvas_img1.addPointList(rList.halfSize());
			} else if (orderArray[0]==5){
				Canvas_img1.addPointList(pList.halfSize());
			} else {
				Canvas_img1.addPointList(reList.halfSize());
			}
			Canvas_img1.draw();
			if (orderArray[1]==1){
				Canvas_img2.addPointList(dList.halfSize());
			} else if (orderArray[1]==2){
				Canvas_img2.addPointList(wList.halfSize());
			} else if (orderArray[1]==3){
				Canvas_img2.addPointList(oList.halfSize());
			} else if (orderArray[1]==4){
				Canvas_img2.addPointList(rList.halfSize());
			} else if (orderArray[1]==5){
				Canvas_img2.addPointList(pList.halfSize());
			} else {
				Canvas_img2.addPointList(reList.halfSize());
			}
			Canvas_img2.draw();
			if (orderArray[2]==1){
				Canvas_img3.addPointList(dList.halfSize());
			} else if (orderArray[2]==2){
				Canvas_img3.addPointList(wList.halfSize());
			} else if (orderArray[2]==3){
				Canvas_img3.addPointList(oList.halfSize());
			} else if (orderArray[2]==4){
				Canvas_img3.addPointList(rList.halfSize());
			} else if (orderArray[2]==5){
				Canvas_img3.addPointList(pList.halfSize());
			} else {
				Canvas_img3.addPointList(reList.halfSize());
			}
			Canvas_img3.draw();
			if (orderArray[3]==1){
				Canvas_img4.addPointList(dList.halfSize());
			} else if (orderArray[3]==2){
				Canvas_img4.addPointList(wList.halfSize());
			} else if (orderArray[3]==3){
				Canvas_img4.addPointList(oList.halfSize());
			} else if (orderArray[3]==4){
				Canvas_img4.addPointList(rList.halfSize());
			} else if (orderArray[3]==5){
				Canvas_img4.addPointList(pList.halfSize());
			} else {
				Canvas_img4.addPointList(reList.halfSize());
			}
			Canvas_img4.draw();
			if (orderArray[4]==1){
				Canvas_img5.addPointList(dList.halfSize());
			} else if (orderArray[4]==2){
				Canvas_img5.addPointList(wList.halfSize());
			} else if (orderArray[4]==3){
				Canvas_img5.addPointList(oList.halfSize());
			} else if (orderArray[4]==4){
				Canvas_img5.addPointList(rList.halfSize());
			} else if (orderArray[4]==5){
				Canvas_img5.addPointList(pList.halfSize());
			} else {
				Canvas_img5.addPointList(reList.halfSize());
			}
			Canvas_img5.draw();
			if (orderArray[5]==1){
				Canvas_img6.addPointList(dList.halfSize());
			} else if (orderArray[5]==2){
				Canvas_img6.addPointList(wList.halfSize());
			} else if (orderArray[5]==3){
				Canvas_img6.addPointList(oList.halfSize());
			} else if (orderArray[5]==4){
				Canvas_img6.addPointList(rList.halfSize());
			} else if (orderArray[5]==5){
				Canvas_img6.addPointList(pList.halfSize());
			} else {
				Canvas_img6.addPointList(reList.halfSize());
			}
			Canvas_img6.draw();
		}
		function setSelection(imageNumber){
			document.getElementById('selection').value= orderArray[imageNumber-1];
			document.getElementById('selection'+imageNumber).style.background= 'blue';
			document.getElementById('selection'+imageNumber).style.color= 'white';
			document.getElementById('selection'+imageNumber).style.border= '3px solid white';
			var notSelected= new Array(1, 2, 3, 4, 5, 6);
			notSelected.splice(imageNumber-1, 1);
			for(var i=0; i<5; i++){
				document.getElementById('selection'+notSelected[i]).style.background= 'white';
				document.getElementById('selection'+notSelected[i]).style.color= 'blue';
				document.getElementById('selection'+notSelected[i]).style.border= '3px solid blue';
			}
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' id='onlink'>Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id="layout">
				<div id="originalDIV">
					<canvas id="originalCanvas" width="400px" height="400px"  class='box'>Your browsers does not supplort HTML 5</canvas>
					<br>
					<div id='label'>
						Original Image
					</div> <!-- end of 'label' div -->
				</div>
				<div id="algsDIV">
					<div id="img1DIV">
						<canvas id="img1Canvas" width="200px" height="200px" onClick="setSelection(1)" class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 1
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img1DIV' div -->
					<div id="img2DIV">
						<canvas id="img2Canvas" width="200px" height="200px" onClick="setSelection(2)" class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 2
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img2DIV' div -->
					<br>
					<div id="img3DIV">
						<canvas id="img3Canvas" width="200px" height="200px" onClick="setSelection(3)" class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 3
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img3DIV' div -->
					<div id="img4DIV">
						<canvas id="img4Canvas" width="200px" height="200px" onClick="setSelection(4)" class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 4
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img4DIV' div -->
					<br>
					<div id="img5DIV">
						<canvas id="img5Canvas" width="200px" height="200px" onClick="setSelection(5)"  class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 5
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img5DIV' div -->
					<div id="img6DIV">
						<canvas id="img6Canvas" width="200px" height="200px" onClick="setSelection(6)"  class='box'>Your browsers does not supplort HTML 5</canvas>
						<br>
						<div id='label'>
							Image 6
						</div> <!-- end of 'label' div -->
					</div> <!-- End of 'img5DIV' div -->
				</div> <!-- End of 'aglsDIV' div -->
				<div id="formDIV">
					<form name="form1" id='form1' method="post" action="project.php" class='insetBox'>
						<div class='container'>
							<div id='label2'>
							<?php
								if ( $_POST==null || $_POST['selection']==null){
									echo "Choose the image you think looks closest to the original.";
								} else {
									$value=$_POST['selection'];
									if($value==1){
										echo "You previously selected the Douglas-Peucker Algorithm.";
									} else if ($value==2){
										echo "You previously selected the Visvalingam-Whyatt Algorithm.";
									} else if ($value==3){
										echo "You previously selected the Opheim Algorithm.";
									} else if ($value==4){
										echo "You previously selected the Radial Distance Algorithm.";
									} else if ($value==5){
										echo "You previously selected the Perpendicular Distance Algorithm.";
									} else if ($value==6){
										echo "You previously selected the Reumann-Witkam Algorithm.";
									}
									echo "<br><br>Choose the image you think looks closest to the original again.";
									$count=0;
									$file=fopen("./results/alg".$value.".txt","r");
									$count= fgets($file);
									fclose($file);
									$count++;
									$handle = fopen("./results/alg".$value.".txt", 'w');
									fwrite($handle, $count);
									fclose($handle);
								}
							?>
							</div> <!-- end of 'label' div -->
							<br>
							<div id='selector'>
								<div id='selection1' onClick="setSelection(1)" class='box'>
									Image 1
								</div>
								<div id='selection2' onClick="setSelection(2)" class='box'>
									Image 2
								</div>
								<br>
								<div id='selection3' onClick="setSelection(3)" class='box'>
									Image 3
								</div>
								<div id='selection4' onClick="setSelection(4)" class='box'>
									Image 4
								</div>
								<br>
								<div id='selection5' onClick="setSelection(5)" class='box'>
									Image 5
								</div>
								<div id='selection6' onClick="setSelection(6)" class='box'>
									Image 6
								</div>
							</div> <!-- end of 'selection' div -->
							<input id='selection' name='selection' type='hidden' value='0' />
							<input id='submitButton' name="Submit" type="submit" value="Submit" class='box'/>
						</div> <!-- End of '.container' div -->
					</form>
				</div> <!-- End of 'formDIV' div -->
			</div> <!-- End of 'newLayout' div -->
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

/*
	Math Library
	Create by Dustin Poissant on 10/05/2012.
	Edited by Dustin Poissant on 10/08/2012.
	Edited by Dustin Poissant on 10/09/2012.
*/
function distance(point1, point2){
	return Math.sqrt( Math.pow( ( point1.x - point2.x ), 2 ) + Math.pow( ( point1.y - point2.y ), 2 ) );
}
function distanceToLine(Line, Point){
	var d;
	//if (Line.p1.x == Line.p2.x && Line.p1.y == Line.p2.y ){
	if (false){
		d= distnace(Line.p1, Point);
		return 400;
	} else {
		// Slope 
		var m= (Line.p1.y-Line.p2.y)/(Line.p1.x-Line.p2.x);
		// Y Intercept
		// Y=mX+b
		// Y-b=mX
		// -b=mX-Y
		// b= -(mX-Y)
		// b= -mX+Y
		// b= Y - mX
		var b = Line.p1.y - ( m * Line.p1.x );	
		// Distance to Point Formula
		return Math.abs( Point.y - ( m * Point.x ) - b ) / Math.sqrt( Math.pow( m, 2 ) + 1);
	}
}
// Helper Class
function Line(Point1, Point2) {
	this.p1 = Point1;
	this.p2 = Point2;
};
function triangleArea(Point1, Point2, Point3){
	var line, point, base, height;
	line= new Line(Point1, Point2);
	point= Point3;
	if ( distance(Point1, Point3)>distance(Point1, Point2)){
		line= new Line(Point1, Point3);
		point= Point2;
	}
	if ( distance(Point2, Point3) > distance(line.p1, line.p2)){
		line= new Line(Point2, Point3);
		point= Point1;
	}
	base= distance(line.p1, line.p2);
	height= distanceToLine(line, point);
	if ((base*height)/2>0 || (base*height)/2<0){
		return (base*height)/2;
	} else {
		return 0;
	}
}
function randomInt(min, max){
	return Math.floor((Math.random()*(max-min))+min);
}








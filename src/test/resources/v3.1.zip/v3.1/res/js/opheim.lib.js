/*
*	This Library contains a function which performs the Opheim Algorithm.
*	Created by Dustin Poissant on 11/02/2012
*/
function opheim(PointList, pTolerance, rTolerance){
	var list= PointList.clone();
	var key=0;
	while( key < list.size()-3 ){
		var line= new Line(list.getPoint(key), list.getPoint(key+1));
		var firstOut= key+2;
		while ( firstOut < list.size() && distanceToLine(line, list.getPoint(firstOut)) < pTolerance && distance(list.getPoint(key), list.getPoint(firstOut)) < rTolerance ){
			firstOut++;
		}
		for (var i=key+1; i<firstOut-1; i++){
			list.removePoint(i);
		}
		key++;
	}
	return list;
}

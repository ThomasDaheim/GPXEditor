/*
This class generates a bar graph placed into the div specified in the Constructor Parameters.
Created by Dustin Poissant on 10/01/2012.
Edited by Dustin Poissant on 10/02/2012.
*/
function Bar(){ // Class to hold information about each bar on the bar graph.
	// Public Members
	this.value=0; // The value.
	this.color="black"; // What color the bar will be.
	this.height=200; // The height the bar will be.
	this.label="label"; // The label for this data.
}
function Size(){ // Holds the size of this graph.
	//Public Members
	this.width=500; // Default size is 500px by 500px.
	this.height=500;
}
function Graph(divID){ // Glass that generates a graph.
	// Private Members
	var elementID= divID; // The <div> element ID where the graph will be placed.
	var size= new Size(); // Creates a size Object which stores the size of the graph. 
	var bars= new Array(); // Creates an array to hold each bar.
	var maxHeight= 80; // The bar representing the largest value will have a height of this percentage.
	var graphTitle= "Graph"; // The title that will appear at the top of the graph.
	var background= 0; // The background URL, set to 0 to indicate no background.
	var textColor="black"; // The color the text will be.
	var barWidth=80; // The width of the bars in percentage.
	
	// Private Methods
	function numCols(){
		return (bars.length*2)+2; // Returns the number of columns that the graph will need for use in colspans. Each bar will use 2 colspans.
	}
	function calcHeights(){
		// Find the largest Value
		var maxIndex=0; // Initialize the index of the Maximum value to the first Bar object's index.
		var max=bars[maxIndex].value; // Set the current max value to the value of the first Bar object. 
		for (var i=1; i<bars.length; i++){ // Starting at the second Bar object loop through each Bar Object.
			if (max<bars[i].value){ // If the currently selected Bar object's value is higher than the current max value.
				max=bars[i].value; // Set the max value to the current Bar object's value.
				maxIndex=i; // Set the maxIndex to the current index.
			}
		}
		//Set Heights
		for (var i=0; i<bars.length; i++){ // Loop through each Bar object.
				bars[i].height=(bars[i].value/bars[maxIndex].value)*((maxHeight*(size.height*0.8))/100); // Set each Bar objects height relative to the maxHeight
		}
	}
	
	// Public Methods
	this.setSize= function(width, height){ // Set the size of the graph.
		if (width>0 && height>0){ // If the parameters are larger than 0.
			size.height=height; // Set the graphs height to the height parameter.
			size.width=width; // Set the graphs width to the width parameter.
		}
	}
	this.setTextColor= function(color){ // Set the text color of all text in this graph.
		textColor=color;
	}
	this.addBar= function(label, value, color){ // Add a new Bar to the graph.
		bars[bars.length]=new Bar() // Create the new Bar object and place it into the array of Bar objects.
		bars[bars.length-1].value=value; // Set the value of the new Bar object.
		bars[bars.length-1].label=label; // Set the label of the new Bar object.
		bars[bars.length-1].color=color; // Set the color of the new Bar object.
	}
	this.getValue= function(index){
		return bars[index];
	}
	this.setMaxHeight= function(percent){
		if (percent >0 && percent<101){
			maxHeight= percent;
		}
	}
	this.setTitle= function(title){
		graphTitle=title;
	}
	this.setBackground= function(backgroundURL){
		background=backgroundURL;
	}
	this.setBarWidth= function(percent){
		if (percent>5 && percent <101){
			barWidth=percent;
		}
	}
	this.generate= function(){
		calcHeights();
		var str="<table width='"+size.width+"' height='"+size.height+"' id='graph' ";
		if (background!=0){
			str+="style='background-image:URL("+background+")' >";
		} else {
			str+=">";
		}
		str+="<tr width='100%' height='"+(size.height*0.1)+"px'><td height='100%' width='100%' colspan='"+numCols()+"' style='text-align:center;'><h3>"+graphTitle+"</h3></td></tr>";
		str+="<tr width='100%' height='"+(size.height*0.8)+"px'>";
		str+="<td height='100%' colspan='1'></td>";
		for (var i=0; i<bars.length; i++){
			str+="<td colspan='2' style='vertical-align:bottom; text-align:center;'>";
			str+="<center><div style='width:"+barWidth+"%;height:"+(bars[i].height)+"px ;vertical-align:top;background-color:"+bars[i].color+";' >"+bars[i].value+"</div></center></td>";
		}
		str+="<td height='100%' colspan='1'></td>";
		str+="</tr><tr width='100%' height='"+(size.height*0.1)+"px'>";
		str+="<td height='100%' colspan='1'></td>";
		for (var i=0; i<bars.length; i++){
			str+="<td colspan='2' style='text-align:center;' id='barLabel'>"+bars[i].label+"</td>";
		}
		str+="<td height='100%' colspan='1'></td>";
		str+="</tr></table>";
		str+="<style>#graph td{width:"+(size.width*0.1)+"px}";
		str+="#graph {color:"+textColor+";background-size:"+size.width+"px "+size.height+"px;}";
		str+="#graph div {border: 0px solid "+textColor+";</style>";
		document.getElementById(elementID).innerHTML=str;
	}
	
	// Helper Classes
	
}
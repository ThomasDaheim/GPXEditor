/*
	Douglas-Peucker Library
	Contains a function that impliments the Douglas-Peucker Curve Simplification Algorithm.
	Create by Dustin Poissant on 10/09/2012.
*/
function douglas(PointList, Tolerance){
	var pointList= PointList.clone();
	function simplify(PointArray, Tolerance){
		// Create a line from the first to last point.
		var line= new Line(PointArray[0], PointArray[PointArray.length-1]);
		// Find the point furthest from this line.
		var maxIndex=0;
		var maxDistance=0;
		for (var i=1; i< PointArray.length-1; i++){
			var d= distanceToLine(line, PointArray[i]);
			if (d>maxDistance){
				maxIndex=i;
				maxDistance=d;
			}
		}
		
		// If this distance is less than the Tolerance return the first and last points only.
		if (maxDistance<Tolerance){
			return new Array(PointArray[0], PointArray[PointArray.length-1]);
		} else { // If this distance is equal to or greater than the Tolerance, subset the array from the first point to the furthest point, and then from the furthest point to the last point. Recursivly run each subset through the simplify function. Recombined the returned point arrays.
			var before= new Array();
			var after= new Array();
			var combined= new Array();
			for (var i=0; i<maxIndex+1; i++){
				before[before.length]= PointArray[i];
			}
			
			for (var i=maxIndex; i<PointArray.length; i++){
				after[after.length]= PointArray[i];
			}
			before= simplify(before, Tolerance);
			after= simplify(after, Tolerance);
			combined=before.concat(after);
			// Remove duplicates
			for (var i=0; i<combined.length; i++){
				for (var e=0; e<combined.length; e++){
					if (
						e!=i &&
						combined[i].x==combined[e].x &&
						combined[i].y==combined[e].y
					){
						combined.splice(i,1);
					}
				}
			}
			return combined;
		}
	}
	//if (pointList.getPoint(0).toString() == pointList.getPoint( pointList.size()-1 ).toString()){
	if (false){
		// Find the point farthest from the first point
		var maxIndex=1;
		var maxDistance= distance(pointList.getPoint(0), pointList.getPoint(1));
		for (var i=2; i<pointList.size(); i++){
			var d= distance(pointList.getPoint(0), pointList.getPoint(i));
			if (d>maxDistance){
				maxIndex=i;
				maxDistance= d;
			}
		}		
		// Subset the array from the first point to the furthest point, and then from the furthest point to the last point. Recursivly run each subset through the simplify function. Recombined the returned point arrays.
		var before= new PointList(), after=new PointList();
		for (var i=0; i<maxIndex+1; i++){
			before.addPoint( pointList.getPoint(i).x, pointList.getPoint(i).y );
		}
		for (var i=maxIndex; i<pointList.size(); i++){
			after.addPoint( pointList.getPoint(i).x, pointList.getPoint(i).y );
		}
		before.list= simplify(before.list, Tolerance);
		after.list= simplify(after.list, Tolerance);
		before.combine(after);
		return before;
	} else {
		pointList.list= simplify(pointList.list, Tolerance);
		return pointList;
	}
}
/*
	Canvas Class
	Methods to draw a PointList to a Canvas.
	Create by Dustin Poissant on 09/22/2012.
*/
function Canvas(canvasID){
	// Private Members
	var canvas= document.getElementById(canvasID); // A reference to the "canvas" element in the HTML5 document.
	var context= canvas.getContext("2d"); // A reference to the context of the "canvas" element.
	var list;	// Sets the PointList associated with this Canvas Object.
	
	

	// Public Methods
	this.clear= function(){ // Clears the canvas element specified by the 'canvas' variable.
		var w = canvas.width;
		context.clearRect(0,0,w,w);
		canvas.width = 1;
		canvas.width = w;
	}
	this.drawLineSegment= function(point1, point2){ // Draws a line segment between point1 and point2 on the canvas element specified by the 'canvas' variable.
		context.moveTo(point1.x,point1.y);
		context.lineTo(point2.x,point2.y);
		context.stroke();
	}
	this.addPointList= function(PointList){ // Associates a PoinList Object with this Canvas Object.
		list= PointList;
	}
	this.getPointList= function(){ // Returns this Canvas Object's associated PointList Object.
		return list;	
	}
	this.draw= function(){ // Draws a line, on the 'canvas' element specified by the 'canvas' variable, between each point in the assiociated PointList Object.
		for (var i=0; i<list.size()-1; i++){
			this.drawLineSegment(list.getPoint(i), list.getPoint(i+1));
		}
	}
	this.toString= function(){ // Returns a String indicating the lines to be drawn with syntax "(Point1X, Point1Y) -> (Point2X, Point2Y)", each String representing a line segment will be on its own line.
		var str="";
		for (var i=0; i<list.size()-1; i++){
			str+=list.getPoint(i).toString()+" -> "+list.getPoint(i+1)+"<br>";
		}
		return str;
	}
}

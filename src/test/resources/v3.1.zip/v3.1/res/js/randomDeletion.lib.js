/*
	Random Deletion Library
	Created by Dustin Poissant on 10/09/2012.
*/
function randomDeletion(PointList, number_to_keep){
	var list= PointList.clone();
	var numDel= list.size()-number_to_keep;
	for (var i=0; i<numDel; i++){
		list.removePoint(
			randomInt(1,list.size()-1)
		);
	}
	return list;
}
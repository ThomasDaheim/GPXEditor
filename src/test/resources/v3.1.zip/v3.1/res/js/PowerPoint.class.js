/*
*	A Class to display images as if it were a Power Point Presentation.
*	Created by Dustin Poissant on 11/05/2012.
*/
function PowerPoint(imgID){
	/* Private Members */
	var slides= new Array();
	var current=0;
	
	/* Private Methods */
	function setImg(){
		document.getElementById(imgID).src= slides[current];
	}
	
	/* Public Methods */
	this.add= function(imgURL){
		slides[ slides.length ]= imgURL;
	}
	this.next= function(){
		if (current==slides.length-1){
			current=0;
		} else {
			current++;
		}
		setImg();
	}
	this.back= function(){
		if (current==0){
			current= slides.length-1;
		} else {
			current--;
		}
		setImg();
	}
}
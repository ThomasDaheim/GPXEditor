/*
	This Library contains a function which performs the Perpendicular Distance Curve Simplification Algorithm.
	Created by Dustin Poissant on 11/01/2012
*/
function perp(PointList, Tolerance){
	var list= PointList.clone();
	for (var i=1; i<list.size()-1; i++){
		var line= new Line( list.getPoint(i-1), list.getPoint(i+1) );
		var d= distanceToLine( line, list.getPoint(i) );
			if ( d < Tolerance ){
				list.removePoint(i);
				i--;
			}
	}
	return list;
}

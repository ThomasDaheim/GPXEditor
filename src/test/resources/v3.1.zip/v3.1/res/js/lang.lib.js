/*
	This Library contains a function which performs the Lang Algorithm.
	Created by Dustin Poissant on 11/02/2012
*/
function lang(PointList, Tolerance){
	/* Inner Functions */
	var list= PointList.clone();
	
	/* Step 1 - Select the first point as the key point */
	var key=0;
	
	/* Step 2 - Select the last point as the end point */
	var end = list.size()-1;
	
	do{ // Restart at Step 3
		/* Step 3 - If there are no points between the key point and end point. */
		if ( key+1==end ){
			if (end != list.size()-1){ // Step 3.1 - If the end point is not the last point.
				/* Step 3.1.1 - Make the end point the new key point. */
				key=end;
				/* Step 3.1.2 - Make the last point the new end point. */
				end= list.size()-1;
				/*
				*	Step 3.1.3 - Restart step 3 using the new end point
				*		and key points.
				*	If the new key point is not the second form last point, this step
				*		will happen automatically. When this if statement exits,
				*		emidiately the parent if statement will exit, and the while
				*		statement will evalute to true (to restart the do-while loop)
				*		because (key < list.size()-2) will evaluate to true.
				*	If the new key point is the second from last point, the algorithm
				*		exits now because if it restarted to step 3 it would exit 
				*		emediately in step 3 anyway.
				*/
			} else {
				/* 
				*	Step 3.2 - and if the end point is the last point.
				*	This will happen automatically, when this if statement exits
				*		emediately the parent if statement will exit, and the 
				*		while statement will evalute to false.
				*	The while statement will evalute to false because, the end 
				*		point is the last point so (end != list.size()-1) will
				*		evaluate to false, and because there are no points
				*		between the key point and the end point, key is the
				*		second from last point so (key < list.size()-2) will
				*		evaluate to false also, exiting the do-while loop.
				*/
			}
		} else { // Step 4 - If there are points between the key point and the end point. */
			
			/* Step 5 - Create a line between the key point and the end point. */
			var line= new Line( list.getPoint(key), list.getPoint(end) );
			
			/* Step 6 - Find the point between the key point and the end point with the largest perpendicular distance from this line.*/
			var maxIndex= key+1;
			var d= distanceToLine(line, list.getPoint(maxIndex));
			var maxD= d;
			for (var i=maxIndex+1; i<end; i++){
				d= distanceToLine(line list.getPoint(i));
				if (d > maxD){
					maxD=d;
					maxIndex=i;
				}
			}
			
			/* Step 7 - If that distance is greated than some tolerance. */
			if (maxD > Tolerance){
				/* Step 7.1 - Decrament the end point. */
				end--;
				/*
				*	Step 7.1 - Restart at step 3 using the new end point.
				*	This step will happen automatically.
				*	When this if statement exits, emidiately the parent if statement exits
				*		then while statement will be evaluated, (end != list.size()-1)
				*		will evalute to true, and the do-while loop will restart,
				*		restarting the algorithm at step 3.
				*/
			} else { // Step 8 - If that distance is less than, or equal to, the tolerance. 
				/* Step 8.1 - Eliminate all points between the key point and the end point. */
				for (var i=key+1; i<end; i++){
					list.removePoint(i);
				}
				/* Step 8.2 - Make the end point the new key point. */
				key=end;
				/* Step 8.3 - Make the last point the new end point. */
				end= list.size()-1;
				/*
				*	Step 8.4 - Restart at step 3.
				*	If the new key point is not the second form last point, this step
				*		will happen automatically. When this if statement exits,
				*		emidiately the parent if statement will exit, and the while
				*		statement will evalute to true (to restart the do-while loop)
				*		because (key < list.size()-2) will evaluate to true.
				*	If the new key point is the second from last point, the algorithm
				*		exits now because if it restarted to step 3 it would exit 
				*		emediately in step 3 anyway.
				*/
			}
		}
	} while( key < list.size()-2 || end != list.size()-1 );

	return list;
}

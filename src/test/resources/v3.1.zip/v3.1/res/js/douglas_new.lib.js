/*
	Douglas-Peucker Library, Version 3
	Contains a function that impliments the Douglas-Peucker Curve Simplification Algorithm.
	Create by Dustin Poissant on 10/13/2012.
*/
function douglas(pList, Tolerance){
	function simplify(pList, Tolerance){
		var pointList= pList.clone();
		var line= new Line(pointList.getPoint(0), pointList.getPoint(pointList.size()-1) );
		var maxIndex=1;
		var maxDistance= distanceToLine(line, pointList.getPoint(1) );
		for (var i=2; i< pointList.size()-1; i++){
			var d=distanceToLine(line, pointList.getPoint(i) );
			if (maxDistance<d){
				maxIndex=i;
				maxDistance=d;
			}
		}
		if ( maxDistance < Tolerance){
			var first= new PointList();
			first.addPoint( pointList.getPoint(0).x, pointList.getPoint(0).y );
			return first;
		} else {
			var before= new PointList(), after= new PointList();
			for (var i=0; i < maxIndex+1; i++){
				before.addPoint( pointList.getPoint(i).x, pointList.getPoint(i).y);
			}
			for (var i=maxIndex; i < pointList.size(); i++){
				after.addPoint( pointList.getPoint(i).x, pointList.getPoint(i).y);
			}
			before= simplify(before, Tolerance);
			after= simplify(after, Tolerance);
			before.combine(after);
			return before;
		}
	}
	var s= new PointList();
	s=simplify(pList, Tolerance);
	s.addPoint(pList.getPoint( pList.size()-1).x, pList.getPoint( pList.size()-1).y);
	return s;
}
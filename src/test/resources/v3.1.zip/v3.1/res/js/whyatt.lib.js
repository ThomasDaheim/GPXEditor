/*
	This Library contains a function which performs the Visvalingam-Whyatt Curve Simplification Algorithm.
	Created by Dustin Poissant on 10/09/2012
*/
function whyatt(PointList, number_to_keep){
	var list= PointList.clone();
	var num_remove= list.size()-number_to_keep;
	for (var i=0; i<num_remove; i++){
		var minIndex=1;
		var minArea= triangleArea(
			list.getPoint(0),
			list.getPoint(1),
			list.getPoint(2)
		);
		for (var e=2; e< list.size()-1; e++){
			var area= triangleArea(
				list.getPoint(e-1),
				list.getPoint(e),
				list.getPoint(e+1)
			);
			if (area<minArea){
				minIndex=e;
				minArea= area;
			}
		}
		list.removePoint(minIndex);
	}
	return list;
}
<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Results Download Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Results Download - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
	<style>
		#content {
			font-size: 24px;
			text-shadow: 0px 1px 0px white;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'  id='onlink'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px''>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Results Download
			</div> <!-- End of 'pageTitle' div -->
			<?php
				$handle = fopen("./results/results.txt", 'w');
				fwrite($handle, "The results of this Curve Simplification Turk Study is as follows.");
				fwrite($handle, "\n");
				$readin = file('results/alg1.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Douglas-Peucker Algorithm has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg1Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
				$readin = file('results/alg2.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Visvalingam-Whyatt Algorithm has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg2Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
				$readin = file('results/alg3.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Opheim Algorithm has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg3Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
				$readin = file('results/alg4.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Radial Distance Algorithm has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg4Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
				$readin = file('results/alg5.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Perpendicular Distance has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg5Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
				$readin = file('results/alg6.txt');
				$count=0;
				foreach($readin as $count){
					$str='The Reumann-Witkam has been selected '.$count.' times.';
					echo "<br>".$str.'<script> var alg6Count='.$count.';</script>';
					fwrite($handle, $str);
					fwrite($handle, "\n");
				}
			?>
			<br>
			<br>
			<br>
			<br>
			<div id='download'>
				<h3>Download the Results of:</h3>
				<ul>
					<li><a href='./results/results.txt'>All</a></li>
					<li><a href='./results/Alg1.txt'>Douglas-Peucker Algorithm.</a></li>
					<li><a href='./results/Alg2.txt'>Visvalingam-Whyatt Algorithm.</a></li>
					<li><a href='./results/Alg3.txt'>Opheim Algorithm.</a></li>
					<li><a href='./results/Alg4.txt'>Radial Distance Algorithm.</a></li>
					<li><a href='./results/Alg5.txt'>Perpendicular Distance Algorithm.</a></li>
					<li><a href='./results/Alg6.txt'>Reumann-Witkam Algorithm.</a></li>
				</ul>
			</div>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

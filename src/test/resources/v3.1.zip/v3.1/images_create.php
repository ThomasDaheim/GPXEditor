<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Create Image Page
	Created by Dustin Poissant on 10/11/2012.
	Edited by Dustin Poissant on 11/04/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Create an Image - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/images_create.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		var pointList= new PointList();
		pointList.addPoint(0,0);
		var points= false;
		var click= false;
		function drawCanvas(canvasID, PointList){
			var canvas1= new Canvas(canvasID);
			canvas1.addPointList(PointList);
			var pList=canvas1.getPointList();
			canvas1.drawLineSegment( pList.getPoint( pList.size()-2 ), pList.getPoint( pList.size()-1 ));
		}
		function addNewPoint(tableID, PointList){
			PointList.addPoint(PointList.getPoint(PointList.size()-1).x, PointList.getPoint(PointList.size()-1).y);
			createTable('pointsTable', pointList);
			points=true;
		}
		function removeLastPoint(canvasID, tableID, PointList){
			// Create Canvas			
			var canvas= new Canvas(canvasID)
			if ( PointList.size()>1){
				PointList.removePoint( PointList.size()-1);
				createTable(tableID, PointList);
			} else {
				PointList.list[0].x=0;
				PointList.list[0].y=0;
				points=false;
				createTable(tableID, PointList);
				
			}
			// Clear Canvas
			canvas.clear();
			// Add PonitList
			canvas.addPointList(PointList);
			// Draw Canvas
			canvas.draw();
		}
		function createTable(tableID, PointList){
			document.getElementById(tableID).innerHTML="";
			var content="<tr id='titleRow'><td>Point</td><td>X</td><td>Y</td></tr>";
			for(var i=0; i<PointList.size(); i++){
				var PointNumber=i+1;
				content+="<tr><td>"+PointNumber+"</td>";
				content+="<td><input name='pointList[]' ";
				content+="type='text' size='3' maxlength='3' id='p"+PointNumber+"x'";
				content+="value='"+PointList.getPoint(i).x;
				content+="' onChange=\" onChangeUpdate('canvas1', 'pointsTable', pointList) \"/></td>";
				content+="<td><input name='pointList[]' "; 
				content+="type='text' size='3' maxlength='3' id='p"+PointNumber+"y'";
				content+="value='"+PointList.getPoint(i).y;
				content+="' onChange=\" onChangeUpdate('canvas1', 'pointsTable', pointList) \"/></td></tr>";
			}
			document.getElementById(tableID).innerHTML=content;
		}
		function onload(){
			var browserName=navigator.appName;
			if (browserName!="Microsoft Internet Explorer"){
				loadScroll();
				createTable('pointsTable', pointList);
				drawCanvas('canvas1', pointList);
			} else {
				document.getElementById('content').innerHTML="<div id='pageTitle'>This feature is not supported by Microsoft Internet Explorer.</div><br><br><hr /><div id='footer'><br><p> Copyright SUNY Institute of Technology 2012  &copy; </p></div>";
				alert("You are using Microsoft Internet Explorer, This \"Create an Image\" Feature is not supported on your browser.");
			}
		}
		function updatePointList(tableID, PointList){
			for(var i=0; i<PointList.size(); i++){
				var pointNumber=i+1;
				PointList.getPoint(i).x=document.getElementById("p"+pointNumber+"x").value;
				PointList.getPoint(i).y=document.getElementById("p"+pointNumber+"y").value;
			}
		}
		function onChangeUpdate(canvasID, tableID, PointList){
			// Check if number
			for (var i=1; i< PointList.size()+1; i++){
				if( isNaN(document.getElementById("p"+i+"x").value) ){
					document.getElementById("p"+i+"x").value= document.getElementById("p"+(i-1)+"x").value;
					alert("The value you entered is not valid");
				}
				if( isNaN(document.getElementById("p"+i+"y").value) ){
					document.getElementById("p"+i+"y").value= document.getElementById("p"+(i-1)+"y").value;
					alert("The value you entered is not valid");
				}
			}
			updatePointList(tableID, PointList);
			// Create Canvas
			var canvas= new Canvas("canvas1");
			// Add PointList
			canvas.addPointList(PointList);
			// Clear Canvas
			canvas.clear();
			// Draw Canvas
			canvas.draw();			
			points=true;
		}
		function save(){
			var str="<input type='hidden' name='pointListDataInput' value='"+pointList.size()+" ";
			for (var i=0; i<pointList.size(); i++){
				str+=pointList.getPoint(i).x+" ";
				if (i<pointList.size()-1){
					str+=pointList.getPoint(i).y+" ";
				} else {
					str+=pointList.getPoint(i).y;
				}	
			}
			str+="' width='100%' />"
			document.getElementById('pointListData').innerHTML=str;
			document.form.submit();
		}
		document.addEventListener("DOMContentLoaded", init, false);
		function init(){
			var canvas = document.getElementById("canvas1");
			canvas.addEventListener("mousemove", canvasMove, false);
			canvas.addEventListener("mousedown", makePoint, false);
		}
		function canvasMove(event){
			if(click){
				makePoint(event);
			}
		}
		function makePoint(event){
			var x = new Number();
			var y = new Number();
			var canvas = document.getElementById("canvas1");

			if (event.x != undefined && event.y != undefined){
			  x = event.x;
			  y = event.y;
			}
			else{ // Firefox method to get the position
			  x = event.clientX + document.body.scrollLeft +
				  document.documentElement.scrollLeft;
			  y = event.clientY + document.body.scrollTop +
				  document.documentElement.scrollTop;
			}

			x -= canvas.offsetLeft;
			y -= canvas.offsetTop;
			var vscroll = (document.all ? document.scrollTop : window.pageYOffset);
			var userAgentVar = navigator.userAgent;
			if (userAgentVar.indexOf("Firefox") == "-1"){
				y+=vscroll;
			}
			
			if (points){
				pointList.addPoint(x,y);
			} else {
				pointList.list[0].x=x;
				pointList.list[0].y=y;
				points=true;
			}
			drawCanvas('canvas1', pointList);
			createTable('pointsTable', pointList);
		}
		function reset(){
			pointList.list.splice(1, pointList.size()-1);
			pointList.list[0].x=0;
			pointList.list[0].y=0;
			points=false;
			
			var canvas1= new Canvas("canvas1");
			canvas1.addPointList(pointList);
			canvas1.clear();

			createTable('pointsTable', pointList);
		}
		function clicked(){
			click=true;
		}
		function unclicked(){
			click=false;
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px'>Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px' id='onlink'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Create an Image
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<div id='canvasDIV' class='insetBox'>
				<div id='buttons1'>
					<input type='button' value='Save' class='box' onclick='save()' />
					<input type='button' value='Reset' class='box' onclick='reset()' />
				</div> <!-- End of 'buttons1' div -->
				<div id='canvasWrapper'>
					<canvas id='canvas1' width='400px' height='400px' class='box' onmousedown='clicked()' onmouseup='unclicked()' onmouseout='unclicked()'></canvas>
				</div> <!-- End of 'canvasWrapper' div -->
			</div> <!-- End of 'canvasDIV' div -->
			<br>
			<div id='warning' class='box' width='400px'>
				WARNING:
				<br>The X and Y values of the first point CAN NOT be the same as the X and Y values of the last point.
				<br>See "Shapes" in <a href='./about_code/index.php#issues'>Known Issues</a>.
			</div> <!-- End of 'instructions' div -->
			<div id='dataDIV'>
				<div id='instructions' class='box' >
					Click on the canvas to the left to add a single point.
					<br>Click and drag on the canvas to add mulitiple points.
					<br>Points may also be added manually by changing the values in the table below.
				</div> <!-- End of 'instructions' div -->
				<form id="form" name="form" action="images_createConfirm.php" method="POST">
					<div id="buttons2">
						<input id="addPoint" name="addPoint" type="button" value="Add Point" onClick="addNewPoint('pointsTable',pointList)" class='box'>
						<input id="deletePoint" name="deletePoint" type="button" value="Delete Point" onClick="removeLastPoint('canvas1','pointsTable',pointList)" class='box'>
					</div>
					<table id="pointsTable" class='box'>
						<!--
							Javascript createTable function creates a row for each point in the points array
							and places them here.
						-->
					</table>
					<div id="buttons2">
						<input id="addPoint" name="addPoint" type="button" value="Add Point" onClick="addNewPoint('pointsTable',pointList)" class='box'>
						<input id="deletePoint" name="deletePoint" type="button" value="Delete Point" onClick="removeLastPoint('canvas1','pointsTable',pointList)" class='box'>
					</div>
					<div id='pointListData'></div> <!-- saves the array here before submitting -->
				</form>
			</div> <!-- End of 'dataDIV' div -->
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>

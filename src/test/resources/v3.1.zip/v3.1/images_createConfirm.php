<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Create an Image Confirm Page.
	Created by Dustin Poissant on 10/11/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Create an Image - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px' id='onlink'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Image Creation Successful.
			</div> <!-- End of 'pageTitle' div -->
			<?php
				$filePath="./curves/";
				if (glob($filePath . "*.txt") != false)
				{
					$filecount = count(glob($filePath . "*.txt"));
				}
				$filecount++;
				$filename="./curves/".$filecount.".txt";
				$strArray = explode(' ', $_POST['pointListDataInput']);
				$handle = fopen("$filename", 'w');
				$counter=0;
				foreach ($strArray as &$value) {
					$counter++;
					fwrite($handle, $value);
					if($counter<count($strArray)){
						fwrite($handle, "\n");
					}
				}
				fclose($handle);
				echo "<div id='label' style='font-size:24;text-align:center;width:100%'>Your Image number is ".$filecount."</div>";
			?>
			<table id='layout'>
				<tr>
					<td colspan='2' id="canvasTD">
						<canvas id="myCanvas" width='400px' height='400px' class='box'></canvas>
						<script>
							var pointList= new PointList();
							var canvas= new Canvas('myCanvas');
							<?php
								$file=fopen($filename,"r");
								$size= fgets($file);
								for ($i=0;$i<$size;$i++){
									echo "pointList.addPoint(".fgets($file).",".fgets($file).");";
								}
								fclose($file);
							?>
							canvas.addPointList(pointList);
							canvas.draw();
						</script>
						<?php
							
						?>
					</td>
					<td colspan='2' style="width:100%; padding: 100px;">
						<h3>What to do Next?</h3>
						<ul>
							<li><a href="index.php">Participate in the Project.</a></li>
							<li><a href="images_create.php">Create another Image.</a></li>
							<li><a href="images_repository.php">Veiw the Image Repository.</a></li>
						</ul>
					</td>
				</tr>
			</table> <!-- end of 'layout' table -->
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
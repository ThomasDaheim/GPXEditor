<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Image Repository Page
	Created by Dustin Poissant on 10/10/2012.
	Edited by Dustin Poissant on 10/16/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Image Repository - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/math.lib.js'></script>
	<script type='text/javascript' src='./res/js/douglas.lib.js'></script>
	<script type='text/javascript' src='./res/js/whyatt.lib.js'></script>
	<script type='text/javascript' src='./res/js/nthPoint.lib.js'></script>
	<script type='text/javascript' src='./res/js/randomDeltion.lib.js'></script>
	<script type='text/javascript' src='./res/js/radial.lib.js'></script>
	<script type='text/javascript' src='./res/js/perp.lib.js'></script>
	<script type='text/javascript' src='./res/js/reumann.lib.js'></script>
	<script type='text/javascript' src='./res/js/opheim.lib.js'></script>
	<script type='text/javascript' src='./res/js/reumann.lib.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/images_repository.css' />
	<!-- End of imports -->
	<script>
		var p= new PointList(), a= new PointList(), iNum=
		<?php
			if ( $_POST==null || $_POST['imageSelection']==null){
				echo 1;
			} else {
				echo $_POST['imageSelection'];
			}
		?>;
		populateFromFile(p);
		function onload(){
			loadScroll();
			drawCanvases('cOriginal', 'cAlg', p);
			createTable('tOriginal', p);
			createTable('tAlg', a);
		}
		function populateFromFile(pList){
			<?php
				if ( $_POST==null || $_POST['imageSelection']==null){
					$imageNumber=1;
				} else {
					$imageNumber=$_POST['imageSelection'];
				}
				$file=fopen("./curves/".$imageNumber.".txt","r");
				$size= fgets($file);
				for ($i=0;$i<$size;$i++){
					echo "pList.addPoint(".fgets($file).",".fgets($file).");";
				}
				fclose($file);
			?>
			return pList;
		}
		function drawCanvases(originalID, algID, pointList){
			var cOriginal= new Canvas(originalID);
			cOriginal.addPointList(pointList);
			cOriginal.draw();
			var cAlg= new Canvas(algID);
			var d= douglas(pointList, 5);
			var alg= document.getElementById('algSelection').value;
			if (alg=='d') {
				a= d;
			} else if (alg=='w'){
				a= whyatt(pointList, d.size());
			} else if (alg=='n'){
				a= NthPoint(pointList, 3, d.size());
			} else if (alg=='r'){
				a= radial(pointList, 30);
			} else if (alg=='p'){
				a= perp(pointList, 5.5);
			} else if (alg=='o'){
				a= opheim(pointList, 50, 85);
			} else if (alg=='re'){
				a= reumann(pointList, 55);
			}
			cAlg.addPointList(a);
			cAlg.draw();
			createTable('tAlg', a);
		}
		function changeAlg(char){
			alg=char;
			drawCanvases('cOriginal', 'cAlg', p);
			createTable('tAlg', a);
		}
		function createTable(divID, pointList){
			var content="";
			var size=pointList.size();
			content+="<table id='pTable'><tr id='titleTR'><td colspan='3'>Size: "+size+" Points</td></tr>";
			content+="<tr id='titleTR'><td>Points</td><td>X</td><td>Y</td></tr>";
			for (var i=0; i<size; i++){
				content+="<tr><td id='pNum'>"+(i+1)+"</td><td>"+pointList.getPoint(i).x+"</td><td>"+pointList.getPoint(i).y+"</td></tr>";
			}
			content+="</table>";
			document.getElementById(divID).innerHTML=content;
		}
	</script>
</head>
<body onload="onload()" onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px'  id='onlink'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Image Repository
			</div> <!-- End of 'pageTitle' div -->		
			<table id='layout'>
				<tr>
					<td>
						<div class='formWrapper' class='box'>
							<br>
							<form id="imgSelection" action="images_image.php" method="post">
								<select name="imageSelection" size="1" id="imageSelection" onChange="this.form.submit()" >
									<?php
										$filePath="./curves/";
										if (glob($filePath . "*.txt") != false)
										{
										 $filecount = count(glob($filePath . "*.txt"));
										}
										for($i=1;$i<$filecount+1;$i++){
											if ($i==$imageNumber){
												echo "<option id=\"option".$i."\" value=\"$i\" selected >Image $i</option>";
											} else {
												echo "<option id=\"option".$i."\" value=\"$i\" >Image $i</option>";
											}
										}
										?>
								</select>
							</form> <!-- End of 'imgSelection' form -->
						</div> <!-- End of '.formWrapper' div -->
					</td>
					<td>
						<div class='formWrapper' class='box'>
							<br>
							<form id="imgSelection" action="images_repository.php" method="post">
								<select id='algSelection' name='algSelection' size="1" onChange="drawCanvases('cOriginal', 'cAlg', p)">
									<option value='d'>Douglas-Peucker</option>
									<option value='w'>Visvalingam-Whatt</option>
									<option value='n'>Nth Point Elimination</option>
									<option value='r'>Radial Distance</option>
									<option value='p'>Perpendicular Distance</option>
									<option value='o'>Opheim</option>
									<option value='re'>Reumann-Witkam</option>
								</select>
							</form> <!-- End of 'imgSelection' form -->
						</div> <!-- End of '.formWrapper' div -->
					</td>
				</tr>
				<tr>
					<td>
						<canvas id='cOriginal' width='400px' height='400px' class='box' ></canvas>
					</td>
					<td>
						<canvas id='cAlg' width='400px' height='400px' class='box' ></canvas>
					</td>
				</tr>
				<tr>
					<td>
						<div id='tOriginal' class='tWrapper'>
							PointList Table dynamically genereated here
						</div> <!-- End of 'tOriginal' div -->
					</td>
					<td>
						<div id='tAlg' class='tWrapper'>
							PointList Table dynamically genereated here
						</div> <!-- End of 'tAlg' div -->
					</td>
				</tr>
			</table>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
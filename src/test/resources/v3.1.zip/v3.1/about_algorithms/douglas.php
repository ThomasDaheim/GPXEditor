<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
	Edited by Dustin Poissant on 11/05/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<script type='text/javascript' src='../res/js/PowerPoint.class.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
	<style>
		#powerPoint {
			height: 700px;
		}
		#ppImg {
			width: 900px;
			border-radius: 10px;
		}
		#next, #back {
			position: relative;
			top: -400px;
			opacity: 0.05;
			-webkit-transition : all .7s;
			-moz-transition : all .7s;
			-o-transition : all .7s;
			transition : all .7s;
			cursor: pointer;
		}
		#next:hover, #back:hover {
			opacity: 1;
		}
		#next {
			float: right;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Douglas-Peucker Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<div id="powerPoint">
				<img src='../res/images/douglas/Slide1.png' id='ppImg' class='box' onclick='p.next()' />
				<img src='../res/images/back.png' id='back' onclick='p.back()' />
				<img src='../res/images/next.png' id='next' onclick='p.next()' />
				<script>
					var p= new PowerPoint('ppImg');
					p.add('../res/images/douglas/Slide1.png');
					p.add('../res/images/douglas/Slide2.png');
					p.add('../res/images/douglas/Slide3.png');
					p.add('../res/images/douglas/Slide4.png');
					p.add('../res/images/douglas/Slide5.png');
					p.add('../res/images/douglas/Slide6.png');
					p.add('../res/images/douglas/Slide7.png');
					p.add('../res/images/douglas/Slide8.png');
					p.add('../res/images/douglas/Slide9.png');
					p.add('../res/images/douglas/Slide10.png');
					p.add('../res/images/douglas/Slide11.png');
					p.add('../res/images/douglas/Slide12.png');
					p.add('../res/images/douglas/Slide13.png');
					p.add('../res/images/douglas/Slide14.png');
					p.add('../res/images/douglas/Slide15.png');
					p.add('../res/images/douglas/Slide16.png');
					p.add('../res/images/douglas/Slide17.png');
					p.add('../res/images/douglas/Slide18.png');
					p.add('../res/images/douglas/Slide19.png');
					p.add('../res/images/douglas/Slide20.png');
					p.add('../res/images/douglas/Slide21.png');
					p.add('../res/images/douglas/Slide22.png');
					p.add('../res/images/douglas/Slide23.png');
					p.add('../res/images/douglas/Slide24.png');
				</script>
			</div> <!-- End of 'powerPoint' div -->
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function DouglasPeucker(PointList[], epsilon)
    // Find the point with the maximum distance
    dmax = 0
    index = 0
    for i = 2 to (length(PointList) - 1)
        d = PerpendicularDistance(PointList[i], Line(PointList[1], PointList[end])) 
        if d > dmax
            index = i
            dmax = d
    // If max distance is greater than epsilon, recursively simplify
    if dmax >= epsilon
        // Recursive call
        recResults1[] = DouglasPeucker(PointList[1...index], epsilon)
        recResults2[] = DouglasPeucker(PointList[index...end], epsilon)
 
        // Build the result list
        ResultList[] = {recResults1[1...end-1] recResults2[1...end]}
    else
        ResultList[] = {PointList[1], PointList[end]}
    // Return the result
    return ResultList[]
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/douglas.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
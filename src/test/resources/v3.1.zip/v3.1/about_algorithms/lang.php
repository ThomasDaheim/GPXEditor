<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 11/02/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Lang Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>This algorithm is based on points perpendicular distance to some line, meaning points are kept or eliminated based on their perpendicular distance to a line.</li>
				<li>This algorithm is very similar to the <a href="douglas">Douglas-Peucker Algorithm</a> in that it is a recursive, holistic, perpendicular distance based algorithm.</li>
				<li>The only way in which this algorithm differs from the Douglas-Peucker is in the way subsections are selected for the next recusion of the algorithm.</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>Select the first point as the key point.</li>
				<li>Select the last point as the end point.</li>
				<li>
					If there are no points between the key point and end point.
					<ul>
						<li>
							And if the end point is not the last point.
							<ul>
								<li>Make the end point the new key point.</li>
								<li>Make the last point the new end point.</li>
								<li>Restart step 3 using the new end point and key points.</li>
							</ul>
						</li>
						<li>
							And if the end point is the last point.
							<ul>
								<li>Exit the algorithm</li>
							</ul>
						</li>
					</ul>
				</li>
				<li>
					If there are points between the key point and the end point.
					<ul>
						<li>Continue to step 5.</li>
					</ul>
				</li>
				<li>Create a line between the key point and the end point.</li>
				<li>Find the point between the key point and the end point with the largest perpendicular distance from this line.</li>
				<li>
					If that distance is greated than some tolerance.
					<ul>
						<li>Decrament the end point.</li>
						<li>Restart at step 3 using the new end point.</li>
					</ul>
				</li>
				<li>
					If that distance is less than, or equal to, the tolerance.
					<ul>
						<li>Eliminate all points between the key point and the end point.</li>
						<li>Make the end point the new key point.</li>
						<li>Make the last point the new end point.</li>
						<li>Restart at step 3.</li>
					</ul>
				</li>
				
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function lang(PointList[], Tolerance)
  key=0
  endP= PointList.length-1
  do {
    endP= PointList.length-1
    if (key+1 != endP) // If there are intermediate points
      line= new Line( PointList[key], PointList[endP])
      /* Find the point with the furthest perpendicular distance */
      maxIndex= key+1
      maxD= perpendicularDistance(line, PointList[maxIndex])
      for (i=maxIndex+1; i<endP; i++)
        d= perpendicularDistance(line, PointList[i])
        if (d > maxD)
          maxIndex=i
          maxD=d
      if (maxD > Tolerance)
        endP--;
      else 
        for (i=key+1; i<endP; i++)
          PointList.remove(i)
        key= endP
  } while ( endP != PointList.length-1 )
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/lang.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
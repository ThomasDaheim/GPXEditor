<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Visvalingam-Whyatt Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>The Visvalingam-Whyatt Algorithm is an area based Algorithm which eliminates points based on their effective area.
				<ul>
					<li>A points effective area is defined as the change in total area of the line by adding or removing that point.</li>
				</ul>
				</li>
				<li>This algorithm is dynamic, the algorithm can be ran once, then the number_to_keep can be changed and a new PointList can be returned without having to run the entire algorithm again.</li>
				<li>This algorithm was developed in 1993 by M.  Visvalingam and J.D. Whyatt.</li>
				<li>This algorithm is also known as "Line Gerealisation by repeated elimination of points".</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>Excluding The first and last points, calculate the effective area of each point.</li>
				<li>Remove the point with the least effective area and place it into a stack.</li>
				<li>Repeat steps 1 and 2 until all except the first and last points have been placed into the stack.</li>
				<li>Starting at the top of the stack (the point with the most effective area) remove points and place them back into their proper position in the original point list</li>
				<li> Repeat step 4 until the list is of the desired size.</li>
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function VisvalingamWhyatt(PointList[], number_to_keep)
// Create a copy of the PointList[]
newPointList= PointList.clone()
// While the size is greater than 2
while newPointList.length > 2
	// Create an Array to hold the effective areas
	areas[PointList.length-2]
	// Calculate the effective area for each point
	for i=2 to i=last-1
		areas[i]= effectiveArea(newPointList[i])
	// Find the point with the least effective area
	leastArea= areas[2]
	for i=3 to i=last-1
		if areas[3] < leastArea
			leastArea= areas[3]	
	// Create a stack (Array) to hold points in order of effective area
	stack[]
	// Remove the point with the least effective area and place it into the stack
	stack[stack.length]= newPointList[ newPointList.find(leastArea) ]
	newPointList.remove( newPointList.find(leastArea) )
	// Create a new empty point list the same size as the original PointList.
	returnPointList[PointList]
	// Add the original first and last points in place into the returnPointList
	returnPointList[0]=PointList[0]
	returnPointList[last]=PointList[last]
	// While the size of the returnPointList is less than the number_to_keep
	while returnPointList.length < number_to_keep
		returnPointList[ PointList.find(stack[last] ) ] = stack[last]
	// Return the returnPointList
	return returnPointList
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Simplified Algorithm</h3>
			Assuming you do not need the algorithm to be dynamic, meaning you have a predetermined static number_to_keep the algorithm can be simplified as follows.
			<ol>
				<li>Calculate the point with the least effective area.</li>
				<li>Remove the point with the least effective area.</li>
				<li>Repeat steps 1 and 2 until the Point List is of size 'number_to_keep'.</li>
			</ol>
			<br>
			<h3>Simplified Pseudocode:</h3>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = "function VisvalingamWhyatt(PointList[], number_to_keep)
// Create a hard copy of PointList
returnPointList= PointList.clone()
// Remove points until the returnPointList is of size 'number_to_keep'
while returnPointList>number_to_keep
	// Find the point of least effective area
	minArea= effectiveArea(1)
	minIndex=1
	for i=2 to i=returnPointList.length-1
		if minArea > effectiveArea(i)
			minArea= effectiveArea(i)
			minIndex=i
	// Remove the point of least effective area
	returnPointList.remove(minIndex)
return returnPointList
end";
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/whyatt.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
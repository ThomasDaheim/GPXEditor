<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Reumann-Witkam Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>This is a perpendicular distance based algorithm similar to the <a href="./perp">Perpendicular Distance Algorithm</a>, and the <a href="./douglas">Douglas-Peucker Algorithm</a>.</li>
				<li>The major difference between this algorithm and those mentioned above is that this algoirthm creates a line from the key point to the next point, and not from the previous to the next points.</li>
				<li>Similarly to the Douglas-Peucker Algorithm, this algorithm looks to eliminate multiple points within a single pass and not just one test point as the Perpendicular Distance Algorithm does.</li>
				<li>Also in contrast to the Douglas-Peucker Algorithm this Algorithm is not holisitic but is instead incramental, starting at the first point and working its way to the last.</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>Select the first point as the key point.</li>
				<li>If there is less than 3 points after the key point, end the algorithm.</li>
				<li>Create a line using the key point and the point following the key point.</li>
				<li>Select the point two points after they key point as the first test point.</li>
				<li>
					If the perpendicular distance from the test point to the line is less than a tolerance.
					<ul>
						<li>Incrament the test point.</li>
						<li>Repeat this step using the new test point.</li>
					</ul>
				</li>
				<li>
					If the perpendicular distance from the test point to the line is greater than a tolerance.
					<ul>
						<li>Remove all points between the key point and the point before the current test point. This keeps the key point and the point with the furthest purpendicular distance within tolerance.</li>
						<li>If there are no points between them (because the first test point was larger than the tolerance), no points are eliminated.</li>
					</ul>
				</li>
				<li>Incrament the key point and restart from step 2.</li>
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function reumannWitkam(PointList[], Tolerance)
  key=0
  while (key+3 > PointList.length)
    line= new Line(PointList[ key ], PointList[ key+1 ])
    test= key+2
    while ( perpendicularDistance(line, PointList[test]) < Tolerance )
      test++
    for (i=key+1; i<test-1; i++)
      PointList.remove( i )
    key++
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/reumann.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
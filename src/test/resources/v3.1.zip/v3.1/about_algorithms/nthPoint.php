<!--
	CS 370 Project - Curve Simplification Turk, Version 2.1
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Nth Point Elimination Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>This is not an inteligent algoirthm, it eliminates points based on their position and not on their value.</li>
				<li>This algorithm elimintes ever Nth Point of the algorithm exlucing the first and last points.</li>
				<li>This algorithm is also called the Naive O(or N) Algorighm.</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>Starting at the 2nd point, eliminate every Nth point excluding the last if it is to be eliminate.</li>
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = "function NthPointElimination(PointList[], N)
	returnPointList= PointList.clone()
	for i=1 i<returnPointList.length-2 i+=N-1
		PointList.remove(i)
	return returnPointList
end";
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<h3>Adapted Algorithm:</h3>
			This code is adapted to keep a specific number of points.
			<ol>
				<li>Create a new PointList.</li>
				<li>Remove the first point from the original PointList and place it into the new PointList.</li>
				<li>Remove the last point from the original PointList and store it for later use.</li>
				<li>Create a counter and set it to first point's location.</li>
				<li>In the original PointList remove the point at the location of the counter.</li>
				<li>Incrament the counter by N.
					<ul>
						<li>If the counter ever extends the range of the original PointList reset the counter to the first point's location.</li>
					</ul>
				</li>
				<li>Repeate steps 5 and 6 until the original PointList is of the desired size minus 2 (leaving room for the original first and last points to be readded).</li>
				<li>Add all points from this simplified PointList into the new PointList.</li>
				<li>Add the stored original last point at the end of the new PointList.</li>
				<li>Return the new PointList.</li>
			</ol>
			<br>
			<h3>Adapted Pseudocode:</h3>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = "function NthPointElimination(PointList[], N, number_to_keep)
	returnPointList[0]= PointList[0]
	PointList.remove(0)
	last= PointList[ PointList.length-1 ]
	PointList.remove( PointList.length-1 ]
	counter=0
	while PointList.length > number_to_keep-2
		PointList.remove( counter )
		for i=0 i<N-1 i++
			counter++
			if counter == PointList.length
				counter=0
	returnPointList.merge(PointList)
	returnPointList[ PointList.length ]= last
	return returnPointList
end";
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/nthPoint.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
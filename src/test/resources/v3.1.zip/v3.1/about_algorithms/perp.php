<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Perpendicular Distance Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>This is a brute force distance based algorithm.</li>
				<li>"For each vertex vi, its perpendicular distance to the line segment S(vi-1, vi+1) is computed. All vertices whose distance is smaller than the given tolerance will be removed." (<a href="http://www.codeproject.com/Articles/114797/Polyline-Simplification#headingPD">Elmar de Koning</a>)</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>The first and last points are always kept.</li>
				<li>Set the test point to the second point.</li>
				<li>If the test point is the last point stop the algorithm, otherwise continue.</li>
				<li>Draw a line, from the point before the test point, to the point after the test point.</li>
				<li>Determine the perpendicular distance between the this line and the test point.</li>
				<li>
					If this distance is less than the tolerance.
					<ul>
						<li>Remove the test point.</li>
						<li>Set the new test point to the new point at the location of the previous test point.</li>
						<li>Repeat from step 3.</li>
					</ul>
				</li>
				<li>
					If this distance is greater than the tolerance.
					<ul>
						<li>Set the new test point to the next point.</li>
						<li>Repeat from step 3.</li>
					</ul>
				</li>
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function perpendicularDistance(PointList[], Tolerance)
  testID= 1;
  while ( testID < PointList.length-1 )
    line= new Line( PointList[ testID-1 ], PointList[ testID+1 ] )
    d= perpDistance( line, PointList[ testID ] )
    if( d < Tolerance)
	  PointList.remove( testID )
    else 
      testID++
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/perp.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Radial Distance Algorithm
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<h3>Description:</h3>
			<ul>
				<li>This is a brute force distance based algorithm.</li>
				<li>"It reduces successive vertices that are clustered too closely to a single vertex."(<a href="http://www.codeproject.com/Articles/114797/Polyline-Simplification#headingRD">Elmar de Koning</a>)</li>
			</ul>
			<br>
			<h3>The Algorithm:</h3>
			<ol>
				<li>The first and last points are always kept.</li>
				<li>Select the first point as the key point.</li>
				<li>Select the point after the key point as the test point.</li>
				<li>If the distance between the key point and the test point is less than the tolerance eliminate the test point, and restart at step 3.</li>
				<li>If the distance between the key point and the test point is greater than the tolerance  set the new key point to the current test point and restart at step 3.</li>
				<li>Continue this algorithm until the second from last point is the key point.</li>
			</ol>
			<br>
			<h3>Pseudocode:</h3>
			<div id='code' class='box'>
					<!-- Code View Generated with GeSHi PHP Script -->
					<?php
						$source = "function radialDistance(PointList[], Tolerance)
  keyID= 0
    while (keyID < PointList.length-1
      testID= keyID+1
      while (  keyID < PointList.length-1 && distance( PointList[ keyID ], PointList[ testID ] ) < Tolerance )
        PointList.remove( testID )
      keyID++
end";
						$language= 'javascript';
						$flag=GESHI_FANCY_LINE_NUMBERS;
						
						include_once('../GeSHi/geshi/geshi.php');
						$geshi = new GeSHi($source, $language);
						$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
						$geshi->set_header_type(GESHI_HEADER_PRE);
						echo $geshi->parse_code();
					?>
				</div>
			<br>
			<h3>Javascript Code:</h3>
			<p>(code used in this project)</p>
			<div id='code' class='box'>
				<!-- Code View Generated with GeSHi PHP Script -->
				<?php
					$source = file_get_contents('../res/js/radial.lib.js');
					$language= 'javascript';
					$flag=GESHI_FANCY_LINE_NUMBERS;
					
					include_once('../GeSHi/geshi/geshi.php');
					$geshi = new GeSHi($source, $language);
					$geshi->enable_line_numbers(GESHI_FANCY_LINE_NUMBERS);
					$geshi->set_header_type(GESHI_HEADER_PRE);
					echo $geshi->parse_code();
				?>
			</div>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
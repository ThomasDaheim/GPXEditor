<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	About the Algorithms Page
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>About the Algorithms - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='../res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='../res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/about_algorithms.css' />
	<link rel='stylesheet' type='text/css' href='../res/css/navigation.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			
		}
	</script>
	<style>
		#content {
			text-align: center;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='../index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='../project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='../results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='../results_view.php' style='width: 229px'>View</a></li>
						<li><a href='../results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='../images_repository.php' style='width: 229px'>Images</a>
					<ul>
						<li><a href='../images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='../images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='../images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='../about_project.php' style='width: 229px' id='onlink'>About</a>
					<ul>
						<li><a href='../about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='../about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='../about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				About the Algorithms
			</div> <!-- End of 'pageTitle' div -->
			<br>
			<br><a href="./douglas.php">The Douglas-Peucker Algorithm</a>
			<br>
			<br><a href="./whyatt.php">The Visvalingam-Whyatt Algorithm</a>
			<br>
			<br><a href="./nthPoint.php">The Nth Point Elimination Algorithm</a>
			<br>
			<br><a href="./radial.php">The Radial Distance Algorithm</a>
			<br>
			<br><a href="./perp.php">The Perpendicular Distance Algorithm</a>
			<br>
			<br><a href="./reumann.php">The Reumann-Witkam Algorithm</a>
			<br>
			<br><a href="./opheim.php">The Opheim Algorithm</a>
			<br>
			<br><a href="./lang.php">The Lang Algorithm</a>
			<br>
			<br>
			<br>
			<br>
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
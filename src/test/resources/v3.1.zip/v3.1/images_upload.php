<!--
	CS 370 Project - Curve Simplification Turk, Version 1.3
	Upload an Image Page.
	Created by Dustin Poissant on 10/10/2012.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<head>
	<title>Upload an Image - Curve Simplification</title>
	<!-- Imports needed in this document -->
	<script type='text/javascript' src='./res/js/pointList.class.js'></script>
	<script type='text/javascript' src='./res/js/canvas.class.js'></script>
	<script type='text/javascript' src='./res/js/math.lib.js'></script>
	<script type='text/javascript' src='./res/js/randomDeletion.lib.js'></script>
	<script type='text/javascript' src='./res/js/douglas.lib.js'></script>
	<script type='text/javascript' src='./res/js/whyatt.lib.js'></script>
	<script type='text/javascript' src='./res/js/saveScroll.lib.js'></script>
	<link rel='stylesheet' type='text/css' href='./res/css/site.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/navigation.css' />
	<link rel='stylesheet' type='text/css' href='./res/css/index.css' />
	<!-- End of imports -->
	<script>
		// JavaScript Functions for this document.
		function onload(){
			loadScroll();
		}
	</script>
	<style>
		#innerContent td {
			width:50%;
			text-align:center;
			font-family:Georgia;
			font-size: 32px;
		}
		#innerLayout td {
			font-family:Georgia;
			font-size: 18px;
		}
		#figure {
			text-align:right;
		}
		#caption {
			text-align:center;
			position: relative;
			left:40px;
		}
		#content {
			font-family:Georgia;
			font-size: 32px;
			text-shadow: 0px 1px 0px white;
		}
	</style>
</head>
<body onload='onload()' onunload='saveScroll()'>
	<div id='page'>
		<div id='header'>
			<div id='headerText'>
				Curve Simplification Turk
			</div> <!-- End of 'headerText' -->
		</div> <!-- End of 'header' div -->
		<div id='navigation'>
			<ul>
				<li><a href='index.php' style='width: 229px' >Home</a>
					<ul>
						<li><a href='project.php' style='width: 229px' id='sublast'>Project</a></li>
					</ul>
				</li>
				<li><a href='results_view.php' style='width: 229px'>Results</a>
					<ul>
						<li><a href='results_view.php' style='width: 229px'>View</a></li>
						<li><a href='results_download.php' style='width: 229px' id='sublast' >Download</a></li>
					</ul>
				</li>
				<li><a href='images_repository.php' style='width: 229px' id='onlink'>Images</a>
					<ul>
						<li><a href='images_repository.php' style='width: 229px'>Repository</a></li>
						<li><a href='images_create.php' style='width: 229px'>Create</a></li>
						<li><a href='images_upload.php' style='width: 229px' id='sublast'>Upload</a></li>
					</ul>
				</li>
				<li><a href='about_project.php' style='width: 229px'>About</a>
					<ul>
						<li><a href='about_project.php' style='width: 229px'>The Project</a></li>
						<li><a href='about_algorithms' style='width: 229px'>The Algorithms</a></li>
						<li><a href='about_code/index.php' style='width: 229px' id='sublast' >The Code</a></li>
					</ul>
				</li>
			</ul>
		</div><!-- End of 'navigation' div -->
		<div id='content'>
			<div id='pageTitle'>
				Upload an Image Array Text File
			</div> <!-- End of 'pageTitle' div -->
			<table id="innerLayout">
				<tr id="innerContent">
					<td id="upload" colspan='4'>
						<form action="uploadConfirm.php" method="post" enctype="multipart/form-data">
							<input type="file" name="file" id="file" disabled="disabled" />
							<input type="submit" name="submit" value="Submit" disabled="disabled" />
						</form>
						<font color="red" style="text-shadow: 0 1px 0 #000;font-size:24px;">Due to server restrictions this feature is currently unavailable.</font>
						<br>	
						<br>
						<br>
						<br>
					</td>
				</tr>
				<tr>
					<td colspan='2'>
						<h3>What is an Image Array Text File?</h3>
						<ul>
							<li>Images are drawn as a series of line segments.</li>
							<li>Line segments are drawn between two points.</li>
								<ul><li>Therefore at least two points are nesssisary for a line to be displayed.</li></ul>
							<li>Points are defined by an X and a Y coordinates.</li>
							<li>The X and Y coordinates are stored as numerical values in a plain text file.</li>
							<li>Uploaded Image Array Text Files MUST be in the following format as shown by Figure 1.</li>
							<ul>
								<li>The file extenstion is .txt.</li>
								<li>All coordinate values below 0 or above 400 are allowed but will not be displayed in the viewing window.</li>
								<li>The first line indicates the number of points that will follow.</li>
								<li>The next line is the X coordinatet of the first point.</li>
								<li>The following line is the corresponding Y coordinate.</li>
								<li>The next line is the X coordinatet of the second point.</li>
								<li>The following line is the corresponding Y coordinate.</li>
								<li>This pattern continues until the end of the file.</li>
								<li>When you reach the Y coordinate of the final point, end the file with no blank lines and no special characters indicating the end of the file.</li>
							</ul>
						</ul>
					</td>
					<td colspan='2' id="figure">
						<img src="images/fig01.png" />
						<br />
						<div id='caption'>
							Figure 1
							<br>
							Black text is txt file text, Red text is explanation of each line.
						</div>
					</td>
				</tr>
				<tr>
					<td colspan='2'>
						<h3>What will the image look like?</h3>
						<ul>
							<li>If the Image Array Text File looks as Figure 1 does, then the image generate will look as Figure 2 does.</li>
							<li>The coordinates of each corner are displayed in red in Figure 2.</li>
							<ul>
								<li>The top left corner is (0,0).</li>
								<li>The top right corner is (0,400).</li>
								<li>The bottom left corner is (400,0).</li>
								<li>The bottom right corner is (400,400).</li>
							</ul>
							<li>The points labeled in Figure 1 correspond to those labeled in Figure 2.</li>
							<li>In this example the first and last points (Point 1 and Point 6) are the same, as seen in Figure 1, giving the illusion of the line being a polygon.</li>
						</ul>
					</td>
					<td colspan='2' id="figure">
						<img src="images/fig02.png" />
						<br />
						<div id='caption'>
							Figure 2
							<br>
							Black lines are the generated image, Red text is explanation of the coordinate system.
						</div>
					</td>
				</tr>	
			</table> <!-- end of 'innerLayout' table -->
			<hr />
			<div id='footer'>
				<br>
				<p> Copyright SUNY Institute of Technology 2012  &copy; </p>
			</div> <!-- End of 'footer' div -->
		</div> <!-- End of 'content' div -->
	</div> <!-- End of 'page' div -->
	<br>
	<br>
	<br>
	<br>
</body>
</html>
/*
	CS 370 Project - Curve Simplification Turk
	Nth Point Elimination Algorithm.
	Created by Dustin Poissant on 10/11/2012.
*/
function NthPoint(pList, N, number_to_keep){
	// Create a clone of PointList to be modified and a new PointList to be Returned.
	var pointList= pList.clone();
	var nList= new PointList();
	
	// Add the first point from pointList to nList and then remove it.
	nList.addPoint(pointList.getPoint(0).x, pointList.getPoint(0).y);
	pointList.removePoint(0);
	
	// Store the last point in pointList for later use and remove it.
	var last= pointList.getPoint(pointList.size()-1);
	pointList.removePoint( pointList.size()-1);
	
	// Of the remaining points, eliminate every Nth point until the list size is equal to number_to_keep.
	var counter=1;
	while ( pointList.size()+2 > number_to_keep ){
		pointList.removePoint(counter);
		for (var i=0; i < N; i++){
			counter++;
			if ( counter >= pointList.size()-1 ){
				counter=1;
			}
		}
	}
	// Add the points left in pointsList to nList.
	nList.combine(pointList);
	
	// Add the last point into nList.
	nList.addPoint(last.x, last.y);
	
	return nList;
}
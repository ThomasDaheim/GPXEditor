/*
	This Library contains a function which performs the Radial Distance Curve Simplification Algorithm.
	Created by Dustin Poissant on 11/01/2012
*/
function radial(PointList, Tolerance){
	var list= PointList.clone();
	var key=0;
	while (key < list.size()-1){
		var test=key+1;
		var d= distance(list.getPoint(key), list.getPoint(test));
		while ( test < list.size()-1 && distance(list.getPoint(key), list.getPoint(test)) < Tolerance){
			list.removePoint(test);
		}
		key++;
	}
	return list;
}

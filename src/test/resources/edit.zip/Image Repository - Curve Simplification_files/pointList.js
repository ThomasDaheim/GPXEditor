/*
	PointList Class
	A Class to hold the X and Y values of a point.
	Created by Dustin Poissant on 9/22/2012.
	Edited by Dustin Poissant on 9/23/2012.
	Edited by Dustin Poissant on 10/09/2012.
*/
function Point(x,y){
	// Public Members
	this.x= x;
	this.y= y;
	
	this.toString= function(){
		return "("+ this.x +", "+ this.y +")";
	}
}
/*
	A Class to hold and Array of Point Objects.
	Created by Dustin Poissant on 9/22/2012.
	Edited by Dustin Poissant on 9/23/2012.
	Edited by Dustin Poissant on 10/05/2012.
*/
function PointList(){
	// Public Members
	this.list= new Array(); // An Array to hold Point Objects.
	
	// Public Methods
	this.addPoint= function(x,y){ // Adds a Point Object with Coordinates x,y to the Array of Points.
		this.list[this.list.length]=new Point(x,y);	
	}
	this.removePoint= function(index){ // Removes the Point Object at index 'index'.
		this.list.splice(index,1); // Starting at index 'index' remove 1 object.
	}
	this.getPoint= function(index){ // Returns the Point Object at index 'index'.
		return this.list[index];	
	}
	this.toString= function(){ // Returns a String with each Point's "toString()" on a seperate line.
		var str="";
		for(var i=0; i<this.list.length; i++){
			str+=this.list[i].toString()+"<br>";
		}
		return str;
	}
	this.size= function(){ // Returns the length of the Array of Points.
		return this.list.length;
	}
	this.clone= function(){ // Creates and returns a hard copy of this object, so changes to the copy will not effect the original.
		var newPointList= new PointList();
		for (var i=0; i<this.list.length; i++){
			newPointList.addPoint(this.list[i].x, this.list[i].y);	
		}
		return newPointList;
	}
	this.halfSize= function(){ // Creates and returns a hard copy of this object, with each coordinate value half that of this Object's.
		var newPointList= new PointList();
		for (var i=0; i<this.list.length; i++){
			newPointList.addPoint(this.list[i].x/2, this.list[i].y/2);	
		}
		return newPointList;	
	}
	this.combine= function(PointList){
		for (var i=0; i<PointList.size(); i++){
			this.addPoint(
				PointList.getPoint(i).x,
				PointList.getPoint(i).y
			)
		}
	}
}









/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tf.gpx.edit.extension;

import javafx.scene.paint.Color;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author thomas
 */
public class TestGarminColor {
    @Test
    public void isGarminDisplayColor() {
        assertTrue(GarminColor.isGarminDisplayColor("Black"));
        assertFalse(GarminColor.isGarminDisplayColor("Thomas"));
    }
    
    @Test
    public void getJavaFXColorForName() {
        assertEquals(GarminColor.getJavaFXColorForJSColor("Red"), Color.RED);
        // method defaults to Color.BLACK if nothings was found
        assertEquals(GarminColor.getJavaFXColorForJSColor("Thomas"), Color.BLACK);
    }
    
    @Test
    public void getGarminDisplayColorForJSName() {
        assertEquals(GarminColor.getGarminColorForJSColor("Red"), GarminColor.Red);
        // method defaults to Color.BLACK if nothings was found
        assertEquals(GarminColor.getGarminColorForJSColor("Thomas"), GarminColor.Black);
    }
    
    @Test
    public void getJSColorForJavaFXColor() {
        assertEquals("Red", GarminColor.getJSColorForJavaFXColor(Color.RED));
        // method defaults to "Black" if nothings was found
        assertEquals("Black", GarminColor.getJSColorForJavaFXColor(Color.AZURE));
    }
    
    @Test
    public void getGarminDisplayColorForHexColor_Exceptions1() {
        final Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            GarminColor.getGarminColorForHexColor(null);
            });
        assertTrue(exception.getMessage().contains("Argument is null"));
    }
    
    @Test
    public void getGarminDisplayColorForHexColor_Exceptions2() {
        final Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            GarminColor.getGarminColorForHexColor("12345");
            });
        assertTrue(exception.getMessage().contains("Argument is to short: "));
    }
    
    @Test
    public void getGarminDisplayColorForHexColor_Exceptions3() {
        final Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            GarminColor.getGarminColorForHexColor("#12345");
            });
        assertTrue(exception.getMessage().contains("Argument is to short: "));
    }
    
    @Test
    public void getGarminDisplayColorForHexColor_Exceptions4() {
        Exception exception = assertThrows(NumberFormatException.class, () -> {
            GarminColor.getGarminColorForHexColor("#-+[]()");
            });
    }
    
    @Test
    public void getGarminDisplayColorForHexColor_NoExceptions() {
        // base colors
        assertEquals(GarminColor.getGarminColorForHexColor("ffffff"), GarminColor.White);
        assertEquals(GarminColor.getGarminColorForHexColor("ff0000"), GarminColor.Red);
        assertEquals(GarminColor.getGarminColorForHexColor("008000"), GarminColor.Green);
        assertEquals(GarminColor.getGarminColorForHexColor("0000ff"), GarminColor.Blue);

        // other known colors
        assertEquals(GarminColor.getGarminColorForHexColor("#00008B"), GarminColor.DarkBlue);
        assertEquals(GarminColor.getGarminColorForHexColor("#FF00FF"), GarminColor.Magenta);
        assertEquals(GarminColor.getGarminColorForHexColor("#D3D3D3"), GarminColor.LightGray);

        // unknown colors
        assertEquals(GarminColor.getGarminColorForHexColor("#483D8B"), GarminColor.DarkMagenta); // Color.DARKSLATEBLUE 
        assertEquals(GarminColor.getGarminColorForHexColor("#DEB887"), GarminColor.DarkGray); // Color.BURLYWOOD 
    }
}
